import json
import shutil
import time
import traceback
from pathlib import Path
from typing import List, Optional

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware

# Pipeline imports
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.pipeline.orchestrator import run_pipeline_single
from src.pipeline.audit import AuditLogger
from api.schemas import RunRequest, RunResponse, AuditEntry, RunSummary, OverrideRequest

REPO_ROOT = Path(__file__).resolve().parents[1]
AUDIT_LOG_PATH = REPO_ROOT / "logs" / "audit_log.jsonl"
REVIEW_QUEUE_PATH = REPO_ROOT / "logs" / "review_queue.json"

app = FastAPI(title="Pre-Auth Pipeline API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Health ──────────────────────────────────────────────────────────────────

@app.get("/api/health")
def health():
    return {"status": "ok", "audit_log_exists": AUDIT_LOG_PATH.exists()}


# ── Admin: clear logs (reset the dashboard) ──────────────────────────────────

@app.post("/api/admin/clear-logs")
def clear_logs():
    """
    Reset the demo dashboard: empty the audit log + review queue and remove the
    A2A stores. Scoped to known log paths only — never touches datasets or code.
    """
    cleared = {"audit_entries": 0, "review_queue": 0, "a2a_files": 0}

    if AUDIT_LOG_PATH.exists():
        cleared["audit_entries"] = sum(1 for ln in AUDIT_LOG_PATH.read_text().splitlines() if ln.strip())
        AUDIT_LOG_PATH.write_text("")

    if REVIEW_QUEUE_PATH.exists():
        try:
            cleared["review_queue"] = len(json.loads(REVIEW_QUEUE_PATH.read_text() or "[]"))
        except Exception:
            pass
    REVIEW_QUEUE_PATH.parent.mkdir(parents=True, exist_ok=True)
    REVIEW_QUEUE_PATH.write_text("[]")

    a2a_dir = REPO_ROOT / "logs" / "a2a"
    if a2a_dir.exists():
        cleared["a2a_files"] = sum(1 for f in a2a_dir.rglob("*") if f.is_file())
        shutil.rmtree(a2a_dir, ignore_errors=True)

    return {"status": "ok", "cleared": cleared}


# ── Dataset (real doctor notes for the case picker) ──────────────────────────

NOTES_PATH = REPO_ROOT / "Dataset" / "doctor_notes" / "patient_cases_dataset.xlsx"


@app.get("/api/cases")
def list_cases():
    """Return the real doctor-note dataset so the UI can pick actual cases."""
    from src.extractor.io import load_doctor_notes
    try:
        rows = load_doctor_notes(str(NOTES_PATH))
    except Exception:
        return []
    cases = []
    for r in rows:
        cases.append({
            "patient_id": str(r.get("patient_id", "")),
            "policy_number": str(r.get("policy_number", "")),
            "contact_information": str(r.get("contact_information", "")),
            "specialty": str(r.get("specialty", "")),
            "doctor_note": str(r.get("doctor_note", "")),
        })
    return cases


# ── Pipeline Run ─────────────────────────────────────────────────────────────

@app.post("/api/run", response_model=RunResponse)
def run_pipeline(req: RunRequest):
    """Run the full multi-agent pipeline synchronously and return the result."""
    t0 = time.time()
    result = run_pipeline_single(
        patient_id=req.patient_id,
        policy_number=req.policy_number,
        contact_info=req.contact_info,
        doctor_note=req.doctor_note,
        specialty=req.specialty,
    )
    elapsed_ms = int((time.time() - t0) * 1000)
    return RunResponse(
        correlation_id=result.correlation_id,
        case_id=result.case_id,
        status=result.status,
        reason=result.reason,
        error=result.error,
        elapsed_ms=elapsed_ms,
    )


# ── Runs (Audit Log) ─────────────────────────────────────────────────────────

def _load_all_entries() -> list:
    if not AUDIT_LOG_PATH.exists():
        return []
    entries = []
    with open(AUDIT_LOG_PATH, "r") as f:
        for line in f:
            if not line.strip():
                continue
            try:
                entries.append(json.loads(line))
            except Exception:
                pass
    return entries


@app.get("/api/runs", response_model=List[RunSummary])
def list_runs():
    """Return a summary list of all pipeline runs."""
    entries = _load_all_entries()
    runs: dict = {}
    for entry in entries:
        cid = entry.get("correlation_id")
        if not cid:
            continue
        if cid not in runs:
            runs[cid] = {
                "correlation_id": cid,
                "case_id": entry.get("case_id", "unknown"),
                "timestamp": entry.get("timestamp", ""),
                "decision": "UNKNOWN",
                "agent_count": 0,
            }
        runs[cid]["agent_count"] += 1
        agent = entry.get("agent")
        if agent == "InsurerReviewAgent":
            runs[cid]["decision"] = entry.get("output_snapshot", {}).get("decision", "APPROVED")
        elif agent == "PipelineError":
            runs[cid]["decision"] = "ERROR"

    for r in runs.values():
        if r["decision"] == "UNKNOWN":
            # No InsurerReviewAgent entry => pipeline suspended before a final decision.
            r["decision"] = "PENDING_REVIEW"

    return sorted(runs.values(), key=lambda x: x["timestamp"], reverse=True)


@app.get("/api/runs/{correlation_id}", response_model=List[AuditEntry])
def get_run_entries(correlation_id: str):
    """Return all audit entries for a specific pipeline run."""
    entries = _load_all_entries()
    matched = [e for e in entries if e.get("correlation_id") == correlation_id]
    if not matched:
        raise HTTPException(status_code=404, detail="Run not found")
    return matched


# ── Review Queue ─────────────────────────────────────────────────────────────

def _load_queue() -> list:
    if not REVIEW_QUEUE_PATH.exists():
        return []
    with open(REVIEW_QUEUE_PATH, "r") as f:
        try:
            return json.load(f)
        except Exception:
            return []


def _save_queue(data: list):
    REVIEW_QUEUE_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(REVIEW_QUEUE_PATH, "w") as f:
        json.dump(data, f, indent=2)


@app.get("/api/review-queue")
def get_review_queue():
    return _load_queue()


@app.post("/api/review-queue/{case_id}/override")
def override_review(case_id: str, req: OverrideRequest):
    queue = _load_queue()
    item = next((q for q in queue if q.get("case_id") == case_id), None)
    if not item:
        raise HTTPException(status_code=404, detail="Case not found in queue")

    # Log the override to audit
    audit = AuditLogger(case_id=case_id)
    audit.log(
        "HumanReviewOverride",
        input_data={"queue_entry": item},
        output_data={"decision": req.decision, "note": req.reviewer_note},
    )
    audit.flush()

    # Remove from queue
    new_queue = [q for q in queue if q.get("case_id") != case_id]
    _save_queue(new_queue)
    return {"status": "ok", "decision": req.decision}
