from pydantic import BaseModel
from typing import Optional, List, Any


class RunRequest(BaseModel):
    patient_id: str
    policy_number: str
    contact_info: str
    doctor_note: str
    specialty: str = "General"


class RunResponse(BaseModel):
    correlation_id: str
    case_id: str
    status: str
    reason: Optional[str] = None
    error: Optional[str] = None
    elapsed_ms: int


class AuditEntry(BaseModel):
    agent: str
    timestamp: str
    correlation_id: str
    case_id: str
    input_snapshot: Optional[Any] = None
    output_snapshot: Optional[Any] = None
    metadata: Optional[Any] = None


class RunSummary(BaseModel):
    correlation_id: str
    case_id: str
    timestamp: str
    decision: str
    agent_count: int


class OverrideRequest(BaseModel):
    decision: str  # "APPROVED" | "DENIED"
    reviewer_note: str
