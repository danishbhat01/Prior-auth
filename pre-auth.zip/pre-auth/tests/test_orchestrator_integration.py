"""
End-to-end integration tests for run_pipeline_single.

These exercise the real orchestration wiring and the real PipelineRouter — the
part most likely to break silently when an agent's schema or a routing rule
changes — while faking the agents themselves so no LLM or 400MB embedding model
is needed. Audit + review-queue writes are redirected to a tmp dir.

Coverage:
  * happy path  -> APPROVED, full agent trail, PHI masked before extractor
  * ICD gate    -> PENDING_REVIEW, downstream agents never called
  * low policy retrieval confidence -> PENDING_REVIEW
"""
import json

import pytest

import src.pipeline.orchestrator as orch
import src.pipeline.audit as audit_mod
import src.pipeline.router as router_mod

from src.extractor.schemas import ExtractorOutput
from src.icd.schemas import ICDCodingOutput, ICDMapping
from src.policy.schemas import PolicyAnalysis
from src.form.schemas import PriorAuthForm
from src.critique.schemas import CritiqueReport
from src.reviewer.schemas import FinalAuthorizationDecision

RAW_NOTE = (
    "Patient: Anita Sharma, DOB 04-Jan-1962, Phone 9876543210. "
    "Severe right knee osteoarthritis. Failed physiotherapy. TKR requested."
)

# Tracks which downstream agents were actually invoked in a given run.
calls = {}


class StubLLM:
    def __init__(self, *a, **k):
        pass


class FakeExtractor:
    def __init__(self, *a, **k):
        pass

    def extract(self, specialty, note_text):
        calls["extractor_note_text"] = note_text
        return ExtractorOutput(
            diagnosis=["knee osteoarthritis"],
            clinical_modifiers=["severe", "right"],
            symptoms=["knee pain"],
            duration="18 months",
            failed_treatments=["physiotherapy"],
            imaging="advanced osteoarthritis",
            requested_procedure=["total knee replacement"],
        )


class FakeICD:
    status = "mapped"

    def __init__(self, *a, **k):
        pass

    def code(self, extractor_output, specialty=""):
        return ICDCodingOutput(mappings=[
            ICDMapping(
                diagnosis="knee osteoarthritis",
                icd10_code="M17.11",
                rare_disease=False,
                status=FakeICD.status,
            )
        ])


class FakeRetriever:
    def __init__(self, *a, **k):
        pass

    def retrieve(self, policy_number, query, k=3):
        return []


class FakePolicyAgent:
    retrieval_conf = "high"

    def __init__(self, *a, **k):
        pass

    def analyze(self, extractor_output, icd_output, retrieved_chunks):
        return PolicyAnalysis(
            policy_summary="TKR policy",
            met_criteria=["severe osteoarthritis", "failed conservative therapy", "imaging confirms degeneration"],
            missing_criteria=[],
            supporting_policy_sections=["Section 3.1"],
            retrieval_confidence_summary=FakePolicyAgent.retrieval_conf,
        )


class FakeFormFiller:
    def __init__(self, *a, **k):
        pass

    def fill(self, patient_id, contact_information, policy_number, specialty,
             extractor_output, icd_output, policy_analysis):
        calls["form_filled"] = True
        return PriorAuthForm(
            patient_id=patient_id,
            contact_information=contact_information,
            policy_number=policy_number,
            specialty=specialty,
            diagnosis=extractor_output.diagnosis,
            clinical_modifiers=extractor_output.clinical_modifiers,
            symptoms=extractor_output.symptoms,
            failed_treatments=extractor_output.failed_treatments,
            imaging=extractor_output.imaging,
            requested_procedure=extractor_output.requested_procedure,
            policy_analysis=policy_analysis,
            icd_coding_output=icd_output,
        )


class FakeCritique:
    def __init__(self, *a, **k):
        pass

    def critique(self, form):
        calls["critique_ran"] = True
        return CritiqueReport(result="PASS")


class FakePayer:
    """Stands in for the payer service across the A2A boundary."""
    def __init__(self, *a, **k):
        pass

    def receive_and_review(self, package_json):
        calls["review_ran"] = True
        calls["package_json"] = package_json
        return FinalAuthorizationDecision(decision="APPROVED", reasoning="All criteria met.")


def _fake_submit(package):
    calls["submitted"] = True
    return f"logs/a2a/provider_outbox/{package.correlation_id}.json"


@pytest.fixture(autouse=True)
def wire(monkeypatch, tmp_path):
    """Install fakes + redirect audit/queue writes to a tmp dir for every test."""
    calls.clear()
    FakeICD.status = "mapped"
    FakePolicyAgent.retrieval_conf = "high"

    monkeypatch.setattr(orch, "AzureOpenAILLM", StubLLM)
    monkeypatch.setattr(orch, "ExtractorAgent", FakeExtractor)
    monkeypatch.setattr(orch, "ICDCodingAgent", FakeICD)
    monkeypatch.setattr(orch, "PolicyRetriever", FakeRetriever)
    monkeypatch.setattr(orch, "PolicyAgent", FakePolicyAgent)
    monkeypatch.setattr(orch, "FormFillerAgent", FakeFormFiller)
    monkeypatch.setattr(orch, "CritiqueAgent", FakeCritique)
    # A2A seam: fake the payer service + the provider's submit step.
    monkeypatch.setattr(orch, "PayerReviewService", FakePayer)
    monkeypatch.setattr(orch, "submit_package", _fake_submit)

    # Keep the REAL PipelineRouter, but redirect its side-effect files to tmp.
    monkeypatch.setattr(audit_mod, "LOGS_DIR", tmp_path)
    monkeypatch.setattr(router_mod, "LOGS_DIR", tmp_path)
    monkeypatch.setattr(router_mod, "REVIEW_QUEUE_FILE", tmp_path / "review_queue.json")

    self_tmp = tmp_path
    return self_tmp


def _read_audit(tmp_path):
    log = tmp_path / "audit_log.jsonl"
    if not log.exists():
        return []
    return [json.loads(l) for l in log.read_text().splitlines() if l.strip()]


def _run():
    return orch.run_pipeline_single(
        patient_id="PA001",
        policy_number="P-11",
        contact_info="john.doe@email.com | +1-555-0101",
        doctor_note=RAW_NOTE,
        specialty="Orthopedics",
    )


def test_happy_path_returns_approved(wire):
    result = _run()
    assert result.status == "APPROVED"

    # Every stage ran, in order, and was recorded — including the A2A submission.
    agents = [e["agent"] for e in _read_audit(wire)]
    for expected in ["PHIMasking", "ExtractorAgent", "ICDCodingAgent",
                     "PolicyRetriever", "PolicyAgent", "FormFillerAgent",
                     "CritiqueAgent", "PackageSubmitted", "InsurerReviewAgent"]:
        assert expected in agents, f"missing audit entry for {expected}"

    assert calls.get("submitted") is True      # provider submitted the package
    assert calls.get("review_ran") is True      # payer received + reviewed it


def test_no_raw_phi_crosses_a2a_boundary(wire):
    _run()
    # The serialized package handed to the payer must not contain raw identifiers.
    package_json = calls["package_json"]
    assert "Anita Sharma" not in package_json
    assert "9876543210" not in package_json


def test_phi_masked_before_extractor_and_not_in_audit(wire):
    _run()
    note_seen = calls["extractor_note_text"]
    assert "Anita Sharma" not in note_seen
    assert "9876543210" not in note_seen
    assert "[PATIENT_NAME]" in note_seen and "[PHONE]" in note_seen

    # Raw identifiers must never appear in the persisted audit log.
    raw_log = (wire / "audit_log.jsonl").read_text()
    assert "Anita Sharma" not in raw_log
    assert "9876543210" not in raw_log

    phi = next(e for e in _read_audit(wire) if e["agent"] == "PHIMasking")
    assert phi["output_snapshot"]["raw_phi_sent_to_llm"] is False
    assert set(phi["output_snapshot"]["masked_fields"]) == {"patient_name", "dob", "phone"}


def test_icd_review_required_halts_before_downstream(wire):
    FakeICD.status = "review_required"
    result = _run()

    assert result.status == "PENDING_REVIEW"
    assert result.reason == "ICD_REVIEW_REQUIRED"
    # Downstream agents must not have run.
    assert "form_filled" not in calls
    assert "critique_ran" not in calls
    assert "review_ran" not in calls
    # But PHI masking + extractor + ICD were still recorded.
    agents = [e["agent"] for e in _read_audit(wire)]
    assert "PHIMasking" in agents and "ICDCodingAgent" in agents


def test_low_retrieval_confidence_halts(wire):
    FakePolicyAgent.retrieval_conf = "low"
    result = _run()

    assert result.status == "PENDING_REVIEW"
    assert result.reason == "LOW_RETRIEVAL_CONFIDENCE"
    assert "form_filled" not in calls
