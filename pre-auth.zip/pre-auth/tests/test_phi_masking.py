"""
Regression tests for the PHI masking layer (src/pipeline/phi.py).

These lock in the compliance guarantee demoed in Golden Scenario 4: direct
identifiers are replaced with typed placeholders BEFORE any LLM call, and
clinical text is never masked by accident.
"""
from src.pipeline.phi import mask_phi


def test_golden_scenario_4_exact_masking():
    note = (
        "Patient: Anita Sharma, DOB 04-Jan-1962, Phone 9876543210. "
        "Severe right knee osteoarthritis. Failed physiotherapy. TKR requested."
    )
    result = mask_phi(note)

    assert "Anita Sharma" not in result.masked_text
    assert "04-Jan-1962" not in result.masked_text
    assert "9876543210" not in result.masked_text
    assert "[PATIENT_NAME]" in result.masked_text
    assert "[DOB]" in result.masked_text
    assert "[PHONE]" in result.masked_text
    # Clinical content is preserved.
    assert "osteoarthritis" in result.masked_text
    assert "TKR requested" in result.masked_text
    assert set(result.masked_fields) == {"patient_name", "dob", "phone"}
    assert result.phi_detected is True


def test_narrative_note_format_masks_name_and_address():
    # Dataset template: "Patient <Name>, DOB on file, residing at <addr>, phone <ph>, is a ..."
    note = ("Patient Vikram Iyer, DOB on file, residing at 394 Oak Ave, Miami, "
            "phone +1-555-3178, is a 71-year-old male presenting with behcet disease.")
    r = mask_phi(note)
    assert "Vikram Iyer" not in r.masked_text
    assert "Oak Ave" not in r.masked_text
    assert "+1-555-3178" not in r.masked_text
    assert "[PATIENT_NAME]" in r.masked_text and "[ADDRESS]" in r.masked_text and "[PHONE]" in r.masked_text
    # Clinical content preserved.
    assert "behcet disease" in r.masked_text
    assert {"patient_name", "address", "phone"} <= set(r.masked_fields)


def test_narrative_patient_is_a_not_masked_as_name():
    # "Patient is a 73-year-old male ..." must NOT be flagged as a name.
    note = "Patient is a 73-year-old male presenting with gastro-esophageal reflux disease."
    r = mask_phi(note)
    assert "patient_name" not in r.masked_fields
    assert r.masked_text == note


def test_clinical_note_has_no_false_positives():
    # Numbers here (68-year-old, 90% LAD, triple-vessel) must NOT be masked.
    note = (
        "Patient is a 68-year-old male presenting with refractory coronary artery "
        "disease. Coronary angiography demonstrates severe triple-vessel CAD with "
        "90% LAD stenosis. Cardiology recommends CABG."
    )
    result = mask_phi(note)
    assert result.masked_text == note
    assert result.masked_fields == []
    assert result.phi_detected is False


def test_age_and_duration_not_masked_as_phone():
    note = "Patient is a 64-year-old female with severe right knee pain for 18 months."
    result = mask_phi(note)
    assert result.masked_text == note
    assert result.masked_fields == []


def test_email_and_phone_in_contact_string():
    result = mask_phi("john.doe@email.com | +1-555-0101")
    assert "john.doe@email.com" not in result.masked_text
    assert "+1-555-0101" not in result.masked_text
    assert "[EMAIL]" in result.masked_text
    assert "[PHONE]" in result.masked_text
    assert set(result.masked_fields) == {"email", "phone"}


def test_mrn_and_ssn_masked():
    result = mask_phi("MRN: A1234567. SSN 123-45-6789.")
    assert "A1234567" not in result.masked_text
    assert "123-45-6789" not in result.masked_text
    assert "mrn" in result.masked_fields
    assert "ssn" in result.masked_fields


def test_empty_and_none_are_safe():
    assert mask_phi("").masked_fields == []
    assert mask_phi(None).masked_text == ""
    assert mask_phi(None).phi_detected is False


def test_masked_result_is_safe_to_log():
    # The field-type list must never contain the raw value itself.
    note = "Patient: Anita Sharma, Phone 9876543210."
    result = mask_phi(note)
    joined = " ".join(result.masked_fields)
    assert "Anita" not in joined
    assert "9876543210" not in joined
