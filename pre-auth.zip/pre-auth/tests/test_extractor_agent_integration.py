import pytest
import os
from pathlib import Path
from src.extractor.agent import ExtractorAgent
from src.extractor.io import load_doctor_notes
from src.extractor.schemas import ExtractorOutput
from src.llm.azure import AzureOpenAILLM
from src.llm.gemini import GeminiLLM


def _has_real_azure_key() -> bool:
    key = os.getenv("AZURE_OPENAI_API_KEY")
    return bool(key) and key != "your-api-key"


def _has_gemini_key() -> bool:
    key = os.getenv("GEMINI_API_KEY")
    return bool(key) and key != "your-api-key"


@pytest.mark.skipif(
    not (_has_real_azure_key() or _has_gemini_key()),
    reason="Requires a valid Azure or Gemini API key"
)
def test_integration_doctor_notes_extraction_llm():
    """
    End-to-end extraction against a real LLM provider.
    Provider priority: Azure (matches production target) -> Gemini (local fallback).
    Regression: ensures every list field is actually a list[str], not a bare string.
    """
    dataset_path = Path(__file__).parent.parent / "Dataset" / "doctor_notes" / "patient_cases_dataset.xlsx"
    if not dataset_path.exists():
        pytest.skip(f"Dataset not found at {dataset_path}")

    notes = load_doctor_notes(str(dataset_path))
    assert len(notes) > 0, "No notes found in dataset"

    if _has_real_azure_key():
        llm_client = AzureOpenAILLM()
    else:
        llm_client = GeminiLLM()

    agent = ExtractorAgent(llm_client=llm_client)

    row = notes[0]
    note_text = row.get("doctor_note", "")
    specialty = row.get("specialty", "General")

    output = agent.extract(specialty=specialty, note_text=note_text)

    assert isinstance(output, ExtractorOutput)

    # Regression: every list field must be a real list of strings.
    for field_name in ("diagnosis", "symptoms", "failed_treatments", "requested_procedure"):
        value = getattr(output, field_name)
        assert isinstance(value, list), f"{field_name} must be a list, got {type(value).__name__}"
        assert all(isinstance(x, str) for x in value), f"{field_name} must contain only strings"

    # Scalar fields must be strings.
    assert isinstance(output.duration, str)
    assert isinstance(output.imaging, str)

    # No ICD / CPT / policy leakage into the extractor output.
    serialized = output.model_dump_json().lower()
    assert "icd" not in serialized, "Extractor must not produce ICD content"
    assert "cpt" not in serialized, "Extractor must not produce CPT content"

    # No PHI leakage: the extractor must not echo case_id-like identifiers into the output text.
    case_id = str(row.get("case_id", "")).strip()
    if case_id:
        assert case_id.lower() not in serialized, f"PHI leak: {case_id} present in output"
