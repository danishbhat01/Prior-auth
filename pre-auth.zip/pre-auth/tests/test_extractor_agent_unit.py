import pytest
from src.extractor.agent import ExtractorAgent
from src.extractor.schemas import ExtractorOutput
from src.llm.interfaces import BaseLLM
from pydantic import BaseModel
from typing import Type

class MockLLM(BaseLLM):
    def __init__(self, expected_output: ExtractorOutput):
        self.expected_output = expected_output
        self.call_count = 0
        self.last_prompt = ""
        
    def generate_structured(self, prompt: str, system_prompt: str, response_model: Type[BaseModel], max_retries: int = 3) -> BaseModel:
        self.call_count += 1
        self.last_prompt = prompt
        return self.expected_output

def test_extractor_agent_with_mock_llm():
    mock_output = ExtractorOutput(
        diagnosis=["knee pain"],
        symptoms=["pain"],
        duration="18 months",
        failed_treatments=["NSAIDs"],
        imaging="MRI",
        requested_procedure=["surgery"]
    )
    mock_llm = MockLLM(mock_output)
    agent = ExtractorAgent(llm_client=mock_llm)
    
    output = agent.extract(specialty="Orthopedics", note_text="Patient has knee pain.")
    
    assert mock_llm.call_count == 1
    assert "Orthopedics" in mock_llm.last_prompt
    assert "Patient has knee pain." in mock_llm.last_prompt
    
    # Ensure Patient ID is NOT in the prompt (it shouldn't be passed to extract at all, but let's just make sure it's not magically there)
    assert "PA001" not in mock_llm.last_prompt
    
    assert output.diagnosis == ["knee pain"]
    assert output.symptoms == ["pain"]
