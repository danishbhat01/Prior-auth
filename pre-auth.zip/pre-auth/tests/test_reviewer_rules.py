import pytest
from src.reviewer.agent import InsurerReviewAgent
from src.form.schemas import PriorAuthForm
from src.icd.schemas import ICDCodingOutput, ICDMapping
from src.policy.schemas import PolicyAnalysis
from src.critique.schemas import CritiqueReport

class MockLLM:
    def generate_structured(self, **kwargs):
        pass

def create_base_form():
    return PriorAuthForm(
        patient_id="123",
        contact_information="contact",
        policy_number="POL-1",
        specialty="General",
        diagnosis=["disease"],
        clinical_modifiers=[],
        symptoms=[],
        failed_treatments=[],
        imaging="",
        requested_procedure=["proc"],
        policy_analysis=PolicyAnalysis(
            policy_summary="",
            met_criteria=["crit1"],
            missing_criteria=[],
            supporting_policy_sections=["sec1"],
            retrieval_confidence_summary="high"
        ),
        icd_coding_output=ICDCodingOutput(mappings=[
            ICDMapping(diagnosis="disease", icd10_code="A00", rare_disease=False, status="mapped")
        ])
    )

def test_missing_criteria_denied():
    agent = InsurerReviewAgent(llm_client=MockLLM())
    form = create_base_form()
    # Mock missing criteria
    form.policy_analysis.missing_criteria = ["crit2"]
    
    critique = CritiqueReport(result="PASS", severity="non-critical", issues=[], recommendations=[])
    
    decision = agent._apply_deterministic_rules(form, critique)
    assert decision is not None
    assert decision.decision == "DENIED"
    assert decision.rule_triggered == "MISSING_POLICY_CRITERIA"

def test_critique_critical_fail_pending_review():
    agent = InsurerReviewAgent(llm_client=MockLLM())
    form = create_base_form()
    
    critique = CritiqueReport(result="FAIL", severity="critical", issues=["bad"], recommendations=[])
    
    decision = agent._apply_deterministic_rules(form, critique)
    assert decision is not None
    assert decision.decision == "PENDING_REVIEW"
    assert decision.rule_triggered == "CRITIQUE_CRITICAL_FAIL"

def test_missing_mandatory_fields_pending_review():
    agent = InsurerReviewAgent(llm_client=MockLLM())
    form = create_base_form()
    form.patient_id = "" # Missing field
    
    critique = CritiqueReport(result="PASS", severity="non-critical", issues=[], recommendations=[])
    
    decision = agent._apply_deterministic_rules(form, critique)
    assert decision is not None
    assert decision.decision == "PENDING_REVIEW"
    assert decision.rule_triggered == "MISSING_MANDATORY_FIELDS"

def test_happy_path_returns_none():
    agent = InsurerReviewAgent(llm_client=MockLLM())
    form = create_base_form()
    
    critique = CritiqueReport(result="PASS", severity="non-critical", issues=[], recommendations=[])
    
    decision = agent._apply_deterministic_rules(form, critique)
    assert decision is None
