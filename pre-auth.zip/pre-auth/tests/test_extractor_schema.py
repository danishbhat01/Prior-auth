import pytest
from src.extractor.schemas import ExtractorOutput
from pydantic import ValidationError

def test_extractor_output_defaults():
    output = ExtractorOutput()
    assert output.diagnosis == []
    assert output.symptoms == []
    assert output.duration == ""
    assert output.failed_treatments == []
    assert output.imaging == ""
    assert output.requested_procedure == []

def test_extractor_output_validation():
    output = ExtractorOutput(
        diagnosis=["knee pain"],
        symptoms=["pain", "swelling"],
        duration="6 months",
        failed_treatments=["NSAIDs"],
        imaging="MRI: tear",
        requested_procedure=["surgery"]
    )
    assert output.diagnosis == ["knee pain"]
    assert len(output.symptoms) == 2
    assert output.failed_treatments == ["NSAIDs"]

def test_extractor_output_invalid_type():
    with pytest.raises(ValidationError):
        ExtractorOutput(symptoms="not a list") # type: ignore
