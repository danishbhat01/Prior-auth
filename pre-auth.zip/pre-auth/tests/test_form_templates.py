"""Tests for specialty -> insurer/template resolution and form population."""
from src.form.templates import resolve_template
from src.form.agent import FormFillerAgent
from src.extractor.schemas import ExtractorOutput
from src.icd.schemas import ICDCodingOutput
from src.policy.schemas import PolicyAnalysis


def test_resolve_template_by_specialty():
    assert resolve_template("Orthopedics") == ("T02_Ortho_Specialty", "OrthoFirst Health Plan")
    assert resolve_template("Cardiology")[1] == "HeartCare Advantage"
    assert resolve_template("Rare Disease")[1] == "RarePath Coverage Alliance"


def test_resolve_template_is_case_insensitive():
    assert resolve_template("orthopedics") == resolve_template("Orthopedics")


def test_unknown_specialty_falls_back_to_standard():
    template_id, insurer = resolve_template("Dermatology")
    assert insurer == "Standard Commercial Payer"
    assert template_id == "T01_Standard_Commercial"


def test_form_filler_attaches_insurer():
    form = FormFillerAgent().fill(
        patient_id="PA0001",
        contact_information="x@example.com",
        policy_number="P-011",
        specialty="Cardiology",
        extractor_output=ExtractorOutput(diagnosis=["coronary artery disease"]),
        icd_output=ICDCodingOutput(mappings=[]),
        policy_analysis=PolicyAnalysis(policy_summary="", retrieval_confidence_summary="high"),
    )
    assert form.insurer_name == "HeartCare Advantage"
    assert form.form_template_id == "T03_Cardio_Specialty"
