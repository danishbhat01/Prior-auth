import pytest
from src.pipeline.router import PipelineRouter
from src.pipeline.errors import LowRetrievalConfidenceError
from src.icd.schemas import ICDCodingOutput, ICDMapping
from src.policy.schemas import PolicyAnalysis
from src.critique.schemas import CritiqueReport

def test_icd_review_required_routes_to_human():
    router = PipelineRouter()
    output = ICDCodingOutput(mappings=[
        ICDMapping(diagnosis="unknown disease", icd10_code=None, rare_disease=None, status="review_required")
    ])
    route = router.route_icd_output(output, "test_case")
    assert route == "human_review"

def test_icd_mapped_routes_to_continue():
    router = PipelineRouter()
    output = ICDCodingOutput(mappings=[
        ICDMapping(diagnosis="known disease", icd10_code="A12.3", rare_disease=False, status="mapped")
    ])
    route = router.route_icd_output(output, "test_case")
    assert route == "continue"

def test_low_retrieval_confidence_routes_to_human():
    router = PipelineRouter()
    analysis = PolicyAnalysis(
        policy_summary="test",
        met_criteria=[],
        missing_criteria=[],
        supporting_policy_sections=[],
        retrieval_confidence_summary="low"
    )
    route = router.route_retrieval(analysis, "test_case")
    assert route == "human_review"
    
def test_high_retrieval_confidence_routes_to_continue():
    router = PipelineRouter()
    analysis = PolicyAnalysis(
        policy_summary="test",
        met_criteria=[],
        missing_criteria=[],
        supporting_policy_sections=[],
        retrieval_confidence_summary="high"
    )
    route = router.route_retrieval(analysis, "test_case")
    assert route == "continue"

def test_critique_non_critical_fail_retries():
    router = PipelineRouter()
    critique = CritiqueReport(
        result="FAIL",
        severity="non-critical",
        issues=["minor issue"],
        recommendations=["fix it"]
    )
    route = router.route_critique(critique, "test_case")
    assert route == "retry"

def test_critique_critical_fail_routes_to_human():
    router = PipelineRouter()
    critique = CritiqueReport(
        result="FAIL",
        severity="critical",
        issues=["major issue"],
        recommendations=["cannot fix automatically"]
    )
    route = router.route_critique(critique, "test_case")
    assert route == "human_review"
