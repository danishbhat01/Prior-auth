import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Navbar from './components/Navbar'
import Overview from './pages/Overview'
import LiveDemo from './pages/LiveDemo'
import TrustSafety from './pages/TrustSafety'
import AuditLog from './pages/AuditLog'
import ReviewQueue from './pages/ReviewQueue'

export default function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<Navigate to="/demo" replace />} />
        <Route path="/overview"     element={<Overview />} />
        <Route path="/demo"         element={<LiveDemo />} />
        <Route path="/trust-safety" element={<TrustSafety />} />
        <Route path="/audit"        element={<AuditLog />} />
        <Route path="/review-queue" element={<ReviewQueue />} />
      </Routes>
    </BrowserRouter>
  )
}
