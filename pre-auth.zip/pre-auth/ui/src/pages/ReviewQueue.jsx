import { useEffect, useState } from 'react'

const API = 'http://localhost:8000'

const REASON_LABEL = {
  ICD_REVIEW_REQUIRED:    'ICD codes require manual review',
  LOW_RETRIEVAL_CONFIDENCE:'Policy evidence confidence too low',
  CRITIQUE_CRITICAL_FAIL: 'Form failed critical QA check',
  CRITIQUE_RETRY_FAIL:    'Form failed QA after retry',
}

export default function ReviewQueue() {
  const [queue, setQueue] = useState([])
  const [loading, setLoading] = useState(true)
  const [notes, setNotes] = useState({})
  const [submitting, setSubmitting] = useState(null)

  const load = () => {
    setLoading(true)
    fetch(`${API}/api/review-queue`)
      .then(r => r.json())
      .then(setQueue)
      .finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [])

  async function override(caseId, decision) {
    const note = notes[caseId] || ''
    if (!note.trim()) { alert('Reviewer note is required.'); return }
    setSubmitting(caseId + decision)
    try {
      await fetch(`${API}/api/review-queue/${caseId}/override`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ decision, reviewer_note: note }),
      })
      load()
    } finally {
      setSubmitting(null)
    }
  }

  const pending = queue.length
  const icd  = queue.filter(q => q.halt_reason === 'ICD_REVIEW_REQUIRED').length
  const low  = queue.filter(q => q.halt_reason === 'LOW_RETRIEVAL_CONFIDENCE').length
  const qa   = queue.filter(q => q.halt_reason?.includes('CRITIQUE')).length

  return (
    <div style={{ padding:'1.75rem 2rem' }}>
      <div className="section-title">📋 Human Review Queue</div>
      <div className="section-sub">Cases that could not be automatically decided — requiring a clinical reviewer to approve or deny.</div>

      <div className="metrics">
        {[
          { label:'Total Pending',   val:pending, cls:'plain' },
          { label:'ICD Review',      val:icd,     cls:'amber' },
          { label:'Low Evidence',    val:low,     cls:'amber' },
          { label:'QA Failures',     val:qa,      cls:'red'   },
        ].map(m => (
          <div key={m.label} className="metric-card">
            <div className="metric-label">{m.label}</div>
            <div className={`metric-value ${m.cls}`}>{m.val}</div>
          </div>
        ))}
      </div>

      {loading && <div className="empty-state"><span className="spinner" /></div>}

      {!loading && queue.length === 0 && (
        <div className="empty-state">
          <div className="empty-state-icon">✅</div>
          <div className="empty-state-title">Queue is empty</div>
          <div className="empty-state-sub">All cases have been automatically decided. Great job!</div>
        </div>
      )}

      {queue.map(item => (
        <div key={item.case_id} className="review-row">
          <div className="review-row-header">
            <div>
              <div style={{ display:'flex', alignItems:'center', gap:'.65rem', marginBottom:'.3rem' }}>
                <span className="badge badge-halted">PENDING REVIEW</span>
                <strong>Patient: {item.case_id || item.patient_id}</strong>
              </div>
              <div style={{ fontSize:'.8rem', color:'var(--gray-500)' }}>
                Halted at <strong>{item.halt_agent}</strong> —&nbsp;
                {REASON_LABEL[item.halt_reason] || item.halt_reason}
              </div>
              {item.detail && (
                <div style={{ fontSize:'.75rem', color:'var(--gray-400)', marginTop:'.2rem' }}>
                  Detail: {item.detail}
                </div>
              )}
            </div>
            <div style={{ fontSize:'.72rem', color:'var(--gray-400)', textAlign:'right' }}>
              {item.queued_at?.slice(0,19).replace('T',' ')}
            </div>
          </div>

          <div className="review-actions" style={{ alignItems:'center', gap:'0.75rem' }}>
            <input
              className="field-input"
              style={{ flex:1 }}
              placeholder="Reviewer note (required)"
              value={notes[item.case_id] || ''}
              onChange={e => setNotes(n => ({ ...n, [item.case_id]: e.target.value }))}
            />
            <button
              className="btn-approve"
              disabled={submitting === item.case_id + 'APPROVED'}
              onClick={() => override(item.case_id, 'APPROVED')}
            >
              {submitting === item.case_id + 'APPROVED' ? '…' : '✓ Approve'}
            </button>
            <button
              className="btn-deny"
              disabled={submitting === item.case_id + 'DENIED'}
              onClick={() => override(item.case_id, 'DENIED')}
            >
              {submitting === item.case_id + 'DENIED' ? '…' : '✕ Deny'}
            </button>
          </div>
        </div>
      ))}
    </div>
  )
}
