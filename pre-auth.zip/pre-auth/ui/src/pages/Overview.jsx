import { useEffect, useState } from 'react'
import AgentTimeline from '../components/AgentTimeline'

const API = 'http://localhost:8000'

const BADGE = {
  APPROVED:       'badge-approved',
  DENIED:         'badge-denied',
  PENDING_REVIEW: 'badge-halted',
  ERROR:          'badge-error',
}

export default function Overview() {
  const [runs, setRuns] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('All')
  const [expanded, setExpanded] = useState(null)
  const [entries, setEntries] = useState({})

  const [clearing, setClearing] = useState(false)

  function loadRuns() {
    setLoading(true)
    fetch(`${API}/api/runs`)
      .then(r => r.json())
      .then(setRuns)
      .finally(() => setLoading(false))
  }

  useEffect(() => { loadRuns() }, [])

  async function clearLogs() {
    if (!window.confirm('Clear all runs from the dashboard? This empties the audit log, review queue, and A2A stores.')) return
    setClearing(true)
    try {
      const res = await fetch(`${API}/api/admin/clear-logs`, { method: 'POST' })
      if (!res.ok) {
        alert(`Clear failed: HTTP ${res.status}. Is the backend restarted with the new endpoint? (POST ${API}/api/admin/clear-logs)`)
        return
      }
      setExpanded(null)
      setEntries({})
      loadRuns()
    } catch (e) {
      alert(`Clear failed: ${e.message}. Is the backend running on :8000?`)
    } finally {
      setClearing(false)
    }
  }

  async function expandRun(cid) {
    if (expanded === cid) { setExpanded(null); return }
    setExpanded(cid)
    if (!entries[cid]) {
      const res = await fetch(`${API}/api/runs/${cid}`)
      if (res.ok) {
        const data = await res.json()
        setEntries(e => ({ ...e, [cid]: data }))
      }
    }
  }

  const total    = runs.length
  const approved = runs.filter(r => r.decision === 'APPROVED').length
  const denied   = runs.filter(r => r.decision === 'DENIED').length
  const errs     = runs.filter(r => ['PENDING_REVIEW','ERROR'].includes(r.decision)).length

  const filtered = runs.filter(r =>
    (filter === 'All' || r.decision === filter) &&
    (!search || r.case_id.toLowerCase().includes(search.toLowerCase()) || r.correlation_id.includes(search))
  )

  return (
    <div style={{ padding:'1.75rem 2rem' }}>
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:'1rem' }}>
        <div>
          <div className="section-title">📊 Overview</div>
          <div className="section-sub">Live view of all authorization cases processed through the pipeline.</div>
        </div>
        <div style={{ display:'flex', gap:'.5rem', flexShrink:0 }}>
          <button className="field-select" style={{ cursor:'pointer', width:'auto', padding:'.5rem .9rem' }}
                  onClick={loadRuns} disabled={loading || clearing}>
            ↻ Refresh
          </button>
          <button className="field-select" style={{ cursor:'pointer', width:'auto', padding:'.5rem .9rem', color:'var(--red-700, #b91c1c)', borderColor:'var(--red-200, #fecaca)' }}
                  onClick={clearLogs} disabled={clearing}>
            {clearing ? 'Clearing…' : '🗑 Clear logs'}
          </button>
        </div>
      </div>

      <div className="metrics">
        {[
          { label:'Total Cases',    val:total,    cls:'plain' },
          { label:'Approved',       val:approved, cls:'green' },
          { label:'Denied',         val:denied,   cls:'red' },
          { label:'Pending Review / Errors',val:errs, cls:'amber' },
        ].map(m => (
          <div key={m.label} className="metric-card">
            <div className="metric-label">{m.label}</div>
            <div className={`metric-value ${m.cls}`}>{m.val}</div>
          </div>
        ))}
      </div>

      <div className="filters">
        <input
          className="field-input"
          placeholder="🔍  Search Patient ID or Correlation ID"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <select className="field-select" value={filter} onChange={e => setFilter(e.target.value)}>
          {['All','APPROVED','DENIED','PENDING_REVIEW','ERROR'].map(v => <option key={v}>{v}</option>)}
        </select>
      </div>

      <div style={{ fontSize:'.78rem', color:'var(--gray-400)', marginBottom:'.75rem' }}>
        {filtered.length} case(s) matching filters
      </div>

      {loading && <div className="empty-state"><span className="spinner" /></div>}

      {!loading && filtered.length === 0 && (
        <div className="empty-state">
          <div className="empty-state-icon">📂</div>
          <div className="empty-state-title">No runs found</div>
          <div className="empty-state-sub">Submit a case from the Live Demo to see results here.</div>
        </div>
      )}

      {filtered.map(run => (
        <div key={run.correlation_id}>
          <div className="run-row" onClick={() => expandRun(run.correlation_id)}>
            <div className="run-row-left">
              <span className={`badge ${BADGE[run.decision] || 'badge-halted'}`}>{run.decision}</span>
              <span style={{ fontWeight:700 }}>Patient: {run.case_id}</span>
            </div>
            <div className="run-row-right">
              <span>{run.timestamp?.slice(0,19).replace('T',' ')}</span>
              <span>{run.agent_count} agents</span>
              <span className="corr-id">{run.correlation_id?.slice(0,20)}…</span>
              <span style={{ color:'var(--gray-400)' }}>{expanded === run.correlation_id ? '▲' : '▼'}</span>
            </div>
          </div>
          {expanded === run.correlation_id && (
            <div style={{ padding:'1rem', border:'1px solid var(--gray-200)', borderTop:'none', borderRadius:'0 0 10px 10px', marginBottom:'.5rem', background:'var(--gray-50)' }}>
              <AgentTimeline entries={entries[run.correlation_id] || []} />
            </div>
          )}
        </div>
      ))}
    </div>
  )
}
