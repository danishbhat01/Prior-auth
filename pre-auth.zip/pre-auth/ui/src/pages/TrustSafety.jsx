import { useEffect, useState } from 'react'

const API = 'http://localhost:8000'

export default function TrustSafety() {
  const [phi, setPhi] = useState(null)          // PHIMasking output_snapshot
  const [extract, setExtract] = useState(null)  // ExtractorAgent output_snapshot
  const [loading, setLoading] = useState(true)
  const [hasRun, setHasRun] = useState(false)

  useEffect(() => {
    fetch(`${API}/api/runs`)
      .then(r => r.json())
      .then(async runs => {
        if (!Array.isArray(runs) || runs.length === 0) return
        // runs are sorted newest-first; use the most recent run that has a PHIMasking step.
        for (const run of runs) {
          const res = await fetch(`${API}/api/runs/${run.correlation_id}`)
          if (!res.ok) continue
          const ents = await res.json()
          const phiEntry = ents.find(e => e.agent === 'PHIMasking')
          if (phiEntry) {
            setPhi(phiEntry.output_snapshot || null)
            const ex = ents.find(e => e.agent === 'ExtractorAgent')
            setExtract(ex?.output_snapshot || null)
            setHasRun(true)
            break
          }
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  const maskedFields = phi?.masked_fields || []
  const phiDetected = maskedFields.length > 0
  const fieldsDisplay = maskedFields.length ? maskedFields.join(', ') : 'none'
  const diagnosis = (extract?.diagnosis || []).join(', ') || '—'
  const procedure = (extract?.requested_procedure || []).join(', ') || '—'
  const maskedNote = phi?.masked_note

  // Empty-state placeholder is unambiguous — never a fake "false".
  const detectedText = !hasRun ? '—' : (phiDetected ? 'true' : 'false')
  const fieldsText   = !hasRun ? '—' : fieldsDisplay

  const controls = [
    ['PHI masking (pre-LLM)',     'Direct identifiers (name, DOB, phone, email, MRN) replaced with typed placeholders before any note reaches the LLM', 'ACTIVE'],
    ['Append-only audit log',     'JSONL log — every agent call recorded with full input/output snapshots (append-only, not cryptographically sealed)', 'ACTIVE'],
    ['Critique QA gate',          'LLM validates all form fields before submission to the insurer', 'ACTIVE'],
    ['Human review queue',        'Any uncertain case (low confidence, QA failure) routes to human override', 'ACTIVE'],
    ['Deterministic routing',     'ICD codes and retrieval confidence checked before any LLM call', 'ACTIVE'],
    ['Smart retry with feedback', 'Critique recommendations injected back into Form Filler on retry', 'ACTIVE'],
    ['Medical embedding model',   'PubMedBERT used for policy RAG — understands clinical acronyms like CABG', 'ACTIVE'],
  ]

  return (
    <div style={{ padding: '1.75rem 2rem' }}>
      <div className="section-title">🛡️ Trust & Safety</div>
      <div className="section-sub">How this pipeline protects patient data and maintains clinical integrity.</div>

      {loading && <div className="empty-state"><span className="spinner" /></div>}

      {!loading && (
        <>
          {!hasRun && (
            <div style={{ fontSize:'.8rem', color:'var(--gray-500)', margin:'0 0 1rem' }}>
              No pipeline run found yet — run a case in <strong>Live Demo</strong> to populate live masking evidence below.
            </div>
          )}

          <div className="privacy-grid">
            <div className="privacy-card amber">
              <div className="privacy-card-header">
                <div className="privacy-card-title">🔒 Patient Privacy Boundary</div>
                <span className="badge badge-halted" style={{ fontSize:'.65rem' }}>MASKED BEFORE LLM</span>
              </div>
              <p style={{ fontSize:'.82rem', color:'var(--gray-700)', marginBottom:'.75rem' }}>
                Direct identifiers are masked before the extractor LLM call. Only masked
                clinical text is forwarded downstream — the raw note never reaches the model.
              </p>
              <div className="privacy-line">PHI detected in note: <strong>{detectedText}</strong></div>
              <div className="privacy-line">Fields masked: <strong>{fieldsText}</strong></div>
              <div className="privacy-line">raw_phi_sent_to_llm: <strong style={{ color:'var(--green-700)' }}>false</strong></div>
            </div>

            <div className="privacy-card green">
              <div className="privacy-card-header">
                <div className="privacy-card-title">🤖 What the AI Actually Sees</div>
                <span className="badge badge-ok" style={{ fontSize:'.65rem' }}>✓ PHI SAFE</span>
              </div>
              <div className="privacy-line">PHI detected in note: <span style={{ color: phiDetected ? 'var(--amber-700, #b45309)' : 'var(--green-700)' }}>{detectedText}</span></div>
              <div className="privacy-line">Fields masked: <span style={{ color:'var(--gray-500)' }}>{fieldsText}</span></div>
              <div className="privacy-line">Diagnosis seen by AI: <strong>{diagnosis}</strong></div>
              <div className="privacy-line">Requested procedure: <strong>{procedure}</strong></div>
              <div style={{ marginTop:'.75rem', display:'flex', alignItems:'center', gap:'.4rem', fontSize:'.78rem', color:'var(--green-700)', fontWeight:600 }}>
                ✅ Zero raw PHI reached the AI reasoning steps
              </div>
            </div>
          </div>

          {maskedNote && (
            <div className="card" style={{ marginTop:'.5rem' }}>
              <div className="json-label">Exact masked text handed to the extractor LLM</div>
              <div className="json-terminal-body" style={{ maxHeight:160, whiteSpace:'pre-wrap' }}>
                {maskedNote}
              </div>
            </div>
          )}

          <div className="card" style={{ marginTop:'.5rem' }}>
            <div className="section-title" style={{ marginBottom:'1rem' }}>📋 Pipeline Integrity Controls</div>
            <table style={{ width:'100%', borderCollapse:'collapse', fontSize:'.83rem' }}>
              <tbody>
                {controls.map(([label, desc, st]) => (
                  <tr key={label} style={{ borderBottom:'1px solid var(--gray-100)' }}>
                    <td style={{ padding:'.65rem .5rem', color:'var(--gray-500)', width:'30%' }}>{label}</td>
                    <td style={{ color:'var(--gray-800)', fontWeight:500 }}>{desc}</td>
                    <td style={{ textAlign:'right' }}>
                      <span className="badge badge-ok">{st}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  )
}
