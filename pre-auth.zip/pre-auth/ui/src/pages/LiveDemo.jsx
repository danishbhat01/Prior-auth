import { useState, useCallback } from 'react'
import LeftPanel from '../components/LeftPanel'
import AgentTimeline from '../components/AgentTimeline'

const API = 'http://localhost:8000'

const PROVIDER_STEPS = [
  { n:'1', icon:'🔬', name:'Extractor',      desc:'Reads doctor notes',             agent:'ExtractorAgent' },
  { n:'2', icon:'🏷️', name:'ICD Coder',      desc:'Assigns ICD-10 codes',           agent:'ICDCodingAgent' },
  { n:'3', icon:'📑', name:'Policy RAG',      desc:'Matches insurer policy',         agent:'PolicyAgent' },
  { n:'4', icon:'📄', name:'Form Filler',     desc:'Generates auth package',         agent:'FormFillerAgent' },
  { n:'5', icon:'✅', name:'Critique Agent',  desc:'Performs final QA verification',  agent:'CritiqueAgent' },
]

export default function LiveDemo() {
  const [form, setForm] = useState({
    patient_id: '', policy_number: '', contact_info: '',
    doctor_note: '', specialty: 'Cardiology',
  })
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [entries, setEntries] = useState([])
  const [tab, setTab] = useState('trace')
  const [errors, setErrors] = useState([])

  const onChange = useCallback((k, v) => setForm(f => ({ ...f, [k]: v })), [])

  async function onSubmit() {
    const errs = []
    if (!form.patient_id)    errs.push('Case ID is required.')
    if (!form.policy_number) errs.push('Policy number is required.')
    if (!form.contact_info)  errs.push('Contact info is required.')
    if (form.doctor_note.trim().length < 20) errs.push('A valid clinical note is required.')
    if (errs.length) { setErrors(errs); return }
    setErrors([]); setLoading(true); setResult(null); setEntries([])

    try {
      const res = await fetch(`${API}/api/run`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      const data = await res.json()
      setResult(data)

      // Fetch audit entries for this run
      const runRes = await fetch(`${API}/api/runs/${data.correlation_id}`)
      if (runRes.ok) setEntries(await runRes.json())
    } catch (e) {
      setResult({ status: 'ERROR', error: e.message, correlation_id: '', case_id: form.patient_id, elapsed_ms: 0 })
    } finally {
      setLoading(false); setTab('trace')
    }
  }

  const status = result?.status
  const bannerCls = status === 'APPROVED' ? 'approved' : status === 'DENIED' ? 'denied' : 'halted'
  const insurer = entries.find(e => e.agent === 'FormFillerAgent')?.output_snapshot?.insurer_name || 'Insurance Company'

  return (
    <div className="layout">
      <LeftPanel form={form} onChange={onChange} onSubmit={onSubmit} loading={loading} />

      <main className="right-panel">
        {errors.length > 0 && (
          <div style={{ background:'#fef2f2', border:'1px solid #fecaca', borderRadius:8, padding:'0.75rem 1rem', marginBottom:'1rem' }}>
            {errors.map((e, i) => <div key={i} style={{ fontSize:'.83rem', color:'var(--red-700)' }}>• {e}</div>)}
          </div>
        )}

        {loading && (
          <div className="empty-state">
            <span className="spinner" style={{ width:40, height:40, borderWidth:4 }} />
            <div className="empty-state-title" style={{ marginTop:'1rem' }}>Processing pipeline…</div>
            <div className="empty-state-sub">Running all 6 agents. This may take 15–20 seconds.</div>
          </div>
        )}

        {!loading && !result && (
          <div className="empty-state">
            <div className="empty-state-icon">🏥</div>
            <div className="empty-state-title">Ready to process</div>
            <div className="empty-state-sub">
              Select a sample case from the left panel or enter a new one,<br />
              then click <strong>Run Pipeline</strong> to start.
            </div>
          </div>
        )}

        {!loading && result && (
          <>
            {/* Decision banner */}
            <div className={`decision-banner ${bannerCls}`}>
              <div className={`decision-icon ${bannerCls}`}>
                {status === 'APPROVED' ? '✅' : status === 'DENIED' ? '❌' : '⚠️'}
              </div>
              <div style={{ flex: 1 }}>
                <div className="decision-label">
                  {status === 'APPROVED' ? 'PAYER APPROVED' : 'PAYER DECISION'}
                </div>
                <div className="decision-title">
                  {status === 'APPROVED' ? `Approved by ${insurer}`
                    : status === 'DENIED' ? `Denied by ${insurer}`
                    : 'Pending Human Review'}
                </div>
                {status === 'APPROVED' ? (
                  <div className="decision-checks">
                    {['Member Eligible','Policy Active','Procedure Covered','Provider In-Network','No Duplicate Submission'].map(c => (
                      <div key={c} className="check-pill">✓ {c}</div>
                    ))}
                  </div>
                ) : (
                  <div style={{ fontSize:'.82rem', color:'var(--gray-500)' }}>
                    {result.reason ? `Reason: ${result.reason}` : result.error || 'See details below'}
                  </div>
                )}
              </div>
              <div className="decision-stats">
                <div className="stat-label">Decision Time</div>
                <div className="stat-value">{result.elapsed_ms} <span className="stat-unit">ms</span></div>
                <div className="stat-label" style={{ marginTop:'.5rem' }}>Correlation ID</div>
                <div style={{ fontFamily:'monospace', fontSize:'.68rem', color:'var(--gray-400)' }}>
                  {result.correlation_id?.slice(0,20)}…
                </div>
              </div>
            </div>

            {/* Tabs */}
            <div className="tabs">
              {[['trace','🕐 Audit Trace'],['overview','✅ Overview'],['inspector','🔍 Agent Inspector']].map(([k,l]) => (
                <button key={k} className={`tab-btn ${tab === k ? 'active' : ''}`} onClick={() => setTab(k)}>{l}</button>
              ))}
            </div>

            {/* ── Audit Trace ─────────────────────────────────────── */}
            {tab === 'trace' && (
              <>
                <div className="section-title">🕐 Audit trace</div>
                <div className="section-sub">Timestamped record of every agent invocation. Click to inspect inputs and outputs.</div>
                <AgentTimeline entries={entries} />
              </>
            )}

            {/* ── Overview ────────────────────────────────────────── */}
            {tab === 'overview' && (
              <>
                {/* Provider section */}
                <div className="pipeline-divider" style={{ marginBottom:'.75rem' }}>
                  <span className="pipeline-divider-label label-provider">🏥 HEALTHCARE PROVIDER</span>
                  <div className="pipeline-divider-line" />
                </div>
                <div className="section-title" style={{ marginBottom:'.2rem' }}>Provider AI Workflow</div>
                <div className="section-sub">Clinical information is extracted, validated, coded, and prepared before submission to the payer.</div>
                <div className="pipeline-steps">
                  {PROVIDER_STEPS.map(s => {
                    const entry = entries.find(e => e.agent === s.agent)
                    const ran = !!entry
                    const critiqueResult = s.agent === 'CritiqueAgent' ? (entry?.output_snapshot?.result || 'PASS') : null
                    const failed = ran && critiqueResult === 'FAIL'
                    const circleColor = !ran ? '#d1d5db' : failed ? '#ef4444' : '#22c55e'
                    const statusText = !ran ? '– skipped'
                      : failed ? '✗ FAIL'
                      : critiqueResult === 'PASS' ? '✓ PASS'
                      : '✓ OK'
                    const statusColor = !ran ? 'var(--gray-400)' : failed ? '#b91c1c' : '#15803d'
                    return (
                      <div key={s.n} className="step-node">
                        <div className="step-circle" style={{ background: circleColor }}>{s.n}</div>
                        <div className="step-body">
                          <div className="step-name">{s.icon} {s.name}</div>
                          <div className="step-desc">{s.desc}</div>
                          <div className="step-ok" style={{ color: statusColor }}>{statusText}</div>
                        </div>
                      </div>
                    )
                  })}
                </div>

                {(() => {
                  const submitted = entries.some(e => e.agent === 'PackageSubmitted')
                  const reviewEntry = entries.find(e => e.agent === 'InsurerReviewAgent')
                  const decision = reviewEntry?.output_snapshot?.decision

                  if (!submitted) {
                    // Provider paused before submitting to the payer (e.g. QA/ICD gate).
                    return (
                      <div style={{ margin:'1.75rem 0', padding:'1rem', borderRadius:10, background:'#fffbeb', border:'1px solid #fde68a', textAlign:'center', color:'#b45309', fontSize:'.85rem', fontWeight:600 }}>
                        ⚠️ Package NOT submitted to payer — workflow paused on the provider side{result?.reason ? ` (${result.reason})` : ''}.
                      </div>
                    )
                  }
                  return (
                    <>
                      <div style={{ display:'flex', alignItems:'center', gap:'1rem', margin:'1.75rem 0' }}>
                        <div style={{ flex:1, height:2, background:'linear-gradient(90deg,#22c55e,#3b82f6)', borderRadius:2 }} />
                        <div className="handoff-node">
                          <div className="handoff-title">📦 Authorization Package Submitted</div>
                          <div className="handoff-sub">🔒 PROVIDER → PAYER</div>
                        </div>
                        <div style={{ flex:1, height:2, background:'linear-gradient(90deg,#3b82f6,#f59e0b)', borderRadius:2 }} />
                      </div>

                      <div className="pipeline-divider" style={{ marginBottom:'.75rem' }}>
                        <span className="pipeline-divider-label label-payer">🏛 INSURANCE COMPANY / PAYER</span>
                        <div className="pipeline-divider-line" />
                      </div>
                      <div className="section-title" style={{ marginBottom:'.2rem' }}>Insurance Company Review</div>
                      <div className="section-sub">The payer independently reviewed the submitted package.</div>
                      <div style={{ marginTop:'.75rem', padding:'1rem', borderRadius:10, border:'1px solid var(--gray-200)',
                        background: decision === 'APPROVED' ? '#f0fdf4' : decision === 'DENIED' ? '#fef2f2' : '#fffbeb' }}>
                        <div style={{ fontSize:'.72rem', color:'var(--gray-500)', fontWeight:700 }}>PAYER DECISION</div>
                        <div style={{ fontSize:'1.1rem', fontWeight:800,
                          color: decision === 'APPROVED' ? '#15803d' : decision === 'DENIED' ? '#b91c1c' : '#b45309' }}>
                          {decision || '—'}
                        </div>
                        {reviewEntry?.output_snapshot?.reasoning && (
                          <div style={{ fontSize:'.82rem', color:'var(--gray-700)', marginTop:'.4rem' }}>
                            {reviewEntry.output_snapshot.reasoning}
                          </div>
                        )}
                      </div>
                    </>
                  )
                })()}
              </>
            )}

            {/* ── Agent Inspector ──────────────────────────────────── */}
            {tab === 'inspector' && (
              <>
                <div className="section-title">🔍 Agent Inspector</div>
                <div className="section-sub">Select an agent to inspect its exact input and output payloads.</div>
                {entries.filter(e => e.agent !== 'PipelineError').map((entry, idx) => {
                  const meta = {
                    ExtractorAgent:'🔬 Extractor', ICDCodingAgent:'🏷️ ICD Coder',
                    PolicyRetriever:'🗂️ Policy RAG', PolicyAgent:'📑 Policy Agent',
                    FormFillerAgent:'📄 Form Filler', CritiqueAgent:'✅ Critique Agent',
                    InsurerReviewAgent:'⚖️ Insurance Review',
                  }[entry.agent] || entry.agent
                  return (
                    <details key={idx} style={{ marginBottom:'.75rem' }}>
                      <summary style={{ cursor:'pointer', fontWeight:600, fontSize:'.88rem', padding:'.5rem', borderRadius:6, background:'var(--gray-50)', border:'1px solid var(--gray-200)', listStyle:'none', display:'flex', alignItems:'center', gap:'.5rem' }}>
                        {meta}
                        <span className="badge badge-ok" style={{ marginLeft:'auto' }}>
                          {entry.agent === 'CritiqueAgent' ? entry.output_snapshot?.result || 'PASS'
                          : entry.agent === 'InsurerReviewAgent' ? entry.output_snapshot?.decision || 'OK'
                          : 'OK'}
                        </span>
                      </summary>
                      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'1rem', marginTop:'.5rem' }}>
                        <div>
                          <div className="json-label">↓ Input</div>
                          <div className="json-terminal-header">
                            <div className="json-dots">
                              <div className="json-dot" style={{background:'#ff5f57'}} />
                              <div className="json-dot" style={{background:'#febc2e'}} />
                              <div className="json-dot" style={{background:'#28c840'}} />
                            </div>
                            <span className="json-terminal-title">{entry.agent?.toLowerCase()}.input.json</span>
                          </div>
                          <div className="json-terminal-body">{JSON.stringify(entry.input_snapshot || {}, null, 2)}</div>
                        </div>
                        <div>
                          <div className="json-label">↑ Output</div>
                          <div className="json-terminal-header">
                            <div className="json-dots">
                              <div className="json-dot" style={{background:'#ff5f57'}} />
                              <div className="json-dot" style={{background:'#febc2e'}} />
                              <div className="json-dot" style={{background:'#28c840'}} />
                            </div>
                            <span className="json-terminal-title">{entry.agent?.toLowerCase()}.output.json</span>
                          </div>
                          <div className="json-terminal-body">{JSON.stringify(entry.output_snapshot || {}, null, 2)}</div>
                        </div>
                      </div>
                    </details>
                  )
                })}
              </>
            )}
          </>
        )}
      </main>
    </div>
  )
}
