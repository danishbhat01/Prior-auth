import { useEffect, useState } from 'react'

const API = 'http://localhost:8000'

const AGENTS = ['PHIMasking','ExtractorAgent','ICDCodingAgent','PolicyRetriever','PolicyAgent',
                 'FormFillerAgent','CritiqueAgent','PackageSubmitted','InsurerReviewAgent','PipelineError']

export default function AuditLog() {
  const [allEntries, setAllEntries] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [agentFilter, setAgentFilter] = useState('All')
  const [selected, setSelected] = useState(null)

  useEffect(() => {
    // Fetch all runs then flatten entries
    fetch(`${API}/api/runs`)
      .then(r => r.json())
      .then(async runs => {
        const all = []
        for (const run of runs) {
          const res = await fetch(`${API}/api/runs/${run.correlation_id}`)
          if (res.ok) {
            const ents = await res.json()
            all.push(...ents)
          }
        }
        setAllEntries(all.sort((a,b) => b.timestamp?.localeCompare(a.timestamp)))
      })
      .finally(() => setLoading(false))
  }, [])

  const filtered = allEntries.filter(e =>
    (agentFilter === 'All' || e.agent === agentFilter) &&
    (!search || e.correlation_id?.includes(search) || String(e.case_id).toLowerCase().includes(search.toLowerCase()))
  )

  return (
    <div style={{ padding:'1.75rem 2rem' }}>
      <div className="section-title">🔍 Audit Log Explorer</div>
      <div className="section-sub">Full append-only record of all agent actions across every pipeline run.</div>

      <div className="filters">
        <input
          className="field-input"
          placeholder="🔍  Correlation ID or Patient ID"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <select className="field-select" value={agentFilter} onChange={e => setAgentFilter(e.target.value)}>
          <option value="All">All agents</option>
          {AGENTS.map(a => <option key={a}>{a}</option>)}
        </select>
      </div>

      <div style={{ fontSize:'.78rem', color:'var(--gray-400)', marginBottom:'.75rem' }}>
        {filtered.length} entries
      </div>

      {loading && <div className="empty-state"><span className="spinner" /></div>}

      {!loading && (
        <div style={{ display:'grid', gridTemplateColumns: selected ? '1fr 1fr' : '1fr', gap:'1.5rem' }}>
          <div>
            <table className="audit-table">
              <thead>
                <tr>
                  <th>Timestamp</th>
                  <th>Patient ID</th>
                  <th>Agent</th>
                  <th>Status</th>
                  <th>Correlation ID</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((e, i) => {
                  const isErr = e.agent === 'PipelineError'
                  const isSel = selected === i
                  return (
                    <tr key={i} className={isSel ? 'selected' : ''} onClick={() => setSelected(isSel ? null : i)}>
                      <td style={{ fontFamily:'monospace', fontSize:'.72rem' }}>{e.timestamp?.slice(0,19).replace('T',' ')}</td>
                      <td style={{ fontWeight:600 }}>{e.case_id}</td>
                      <td>{e.agent}</td>
                      <td>
                        <span className={`badge ${isErr ? 'badge-error' : 'badge-ok'}`}>
                          {isErr ? 'ERROR' : 'OK'}
                        </span>
                      </td>
                      <td><span className="corr-id">{e.correlation_id?.slice(0,16)}…</span></td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          {selected !== null && filtered[selected] && (
            <div>
              <div className="section-title" style={{ fontSize:'.92rem', marginBottom:'.25rem' }}>
                {filtered[selected].agent} — Entry Detail
              </div>
              <div style={{ fontSize:'.75rem', color:'var(--gray-400)', marginBottom:'1rem' }}>
                Patient: <strong>{filtered[selected].case_id}</strong> &nbsp;|&nbsp;
                <span className="corr-id">{filtered[selected].correlation_id?.slice(0,20)}…</span>
              </div>

              {filtered[selected].agent === 'PipelineError' ? (
                <div style={{ background:'#fef2f2', border:'1px solid #fecaca', borderRadius:8, padding:'1rem', fontSize:'.82rem', color:'var(--red-700)' }}>
                  <strong>Error:</strong> {filtered[selected].output_snapshot?.error}
                </div>
              ) : (
                <>
                  <div className="json-label">Input Snapshot</div>
                  <div className="json-terminal-header">
                    <div className="json-dots">
                      <div className="json-dot" style={{background:'#ff5f57'}} />
                      <div className="json-dot" style={{background:'#febc2e'}} />
                      <div className="json-dot" style={{background:'#28c840'}} />
                    </div>
                    <span className="json-terminal-title">input.json</span>
                  </div>
                  <div className="json-terminal-body" style={{ maxHeight:200 }}>
                    {JSON.stringify(filtered[selected].input_snapshot || {}, null, 2)}
                  </div>
                  <div style={{ marginTop:'0.75rem' }} />
                  <div className="json-label">Output Snapshot</div>
                  <div className="json-terminal-header">
                    <div className="json-dots">
                      <div className="json-dot" style={{background:'#ff5f57'}} />
                      <div className="json-dot" style={{background:'#febc2e'}} />
                      <div className="json-dot" style={{background:'#28c840'}} />
                    </div>
                    <span className="json-terminal-title">output.json</span>
                  </div>
                  <div className="json-terminal-body" style={{ maxHeight:200 }}>
                    {JSON.stringify(filtered[selected].output_snapshot || {}, null, 2)}
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
