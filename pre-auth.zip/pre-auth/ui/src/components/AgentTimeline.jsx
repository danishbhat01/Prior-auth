import { useState } from 'react'

const AGENT_META = {
  ExtractorAgent:     { icon: '🔬', bg: '#dcfce7', label: 'Extractor' },
  ICDCodingAgent:     { icon: '🏷️', bg: '#d1fae5', label: 'ICD Coder' },
  PolicyRetriever:    { icon: '🗂️', bg: '#ecfdf5', label: 'Policy RAG' },
  PolicyAgent:        { icon: '📑', bg: '#f0fdfa', label: 'Policy Agent' },
  FormFillerAgent:    { icon: '📄', bg: '#e0f2fe', label: 'Form Filler' },
  CritiqueAgent:      { icon: '✅', bg: '#ede9fe', label: 'Critique Agent' },
  InsurerReviewAgent: { icon: '⚖️', bg: '#f5f3ff', label: 'Insurance Review' },
  PipelineError:      { icon: '🛑', bg: '#fee2e2', label: 'Pipeline Error' },
}

const PROVIDER_AGENTS = new Set(['ExtractorAgent','ICDCodingAgent','PolicyRetriever','PolicyAgent','FormFillerAgent','CritiqueAgent'])
const INSURER_AGENTS  = new Set(['InsurerReviewAgent'])

// Real signal per agent (no fabricated percentages). Returns a label or null.
function realSignal(agent, out) {
  if (agent === 'PolicyAgent' && out?.retrieval_confidence_summary) {
    return `retrieval: ${out.retrieval_confidence_summary}`
  }
  if (agent === 'ICDCodingAgent' && Array.isArray(out?.mappings) && out.mappings[0]) {
    const m = out.mappings[0]
    const conf = m.confidence != null ? ` · ${Math.round(m.confidence * 100)}%` : ''
    return `${m.status}${conf}`
  }
  if (agent === 'PHIMasking' && Array.isArray(out?.masked_fields)) {
    return out.masked_fields.length ? `masked: ${out.masked_fields.join(', ')}` : 'no PHI'
  }
  return null
}

function agentBadge(agent, out) {
  if (agent === 'PipelineError') return <span className="badge badge-error">ERROR</span>
  if (agent === 'CritiqueAgent') {
    const r = out?.result || 'OK'
    return <span className={`badge ${r === 'PASS' ? 'badge-pass' : 'badge-denied'}`}>{r}</span>
  }
  if (agent === 'InsurerReviewAgent') {
    const d = out?.decision || 'OK'
    return <span className={`badge ${d === 'APPROVED' ? 'badge-approved' : d === 'DENIED' ? 'badge-denied' : 'badge-halted'}`}>{d}</span>
  }
  return <span className="badge badge-ok">OK</span>
}

export default function AgentTimeline({ entries }) {
  const [expanded, setExpanded] = useState(null)

  if (!entries || entries.length === 0) {
    return <div className="empty-state"><div className="empty-state-icon">🔍</div><div className="empty-state-title">No entries</div><div className="empty-state-sub">Run a pipeline case to see the audit trace.</div></div>
  }

  let providerShown = false
  let handoffShown  = false

  return (
    <div>
      {entries.map((entry, idx) => {
        const agent = entry.agent || ''
        const meta  = AGENT_META[agent] || { icon: '⚙️', bg: '#f3f4f6', label: agent }
        const out   = entry.output_snapshot || {}
        const ts    = (entry.timestamp || '').slice(11, 23)
        const signal = realSignal(agent, out)
        const isErr = agent === 'PipelineError'
        const isOpen = expanded === idx

        let providerHeader  = null
        let handoffDivider  = null

        if (PROVIDER_AGENTS.has(agent) && !providerShown) {
          providerShown = true
          providerHeader = (
            <div className="pipeline-divider" key="ph">
              <span className="pipeline-divider-label label-provider">🏥 HEALTHCARE PROVIDER SIDE</span>
              <div className="pipeline-divider-line" />
            </div>
          )
        }
        if (INSURER_AGENTS.has(agent) && !handoffShown) {
          handoffShown = true
          handoffDivider = (
            <div key="handoff">
              <div style={{ display:'flex', alignItems:'center', gap:'1rem', margin:'1rem 0' }}>
                <div style={{ flex:1, height:'2px', background:'linear-gradient(90deg,#22c55e,#3b82f6)', borderRadius:2 }} />
                <div className="handoff-node">
                  <div className="handoff-title">📦 Authorization Package Submitted</div>
                  <div className="handoff-sub">🔒 PROVIDER → PAYER · ENCRYPTED</div>
                </div>
                <div style={{ flex:1, height:'2px', background:'linear-gradient(90deg,#3b82f6,#f59e0b)', borderRadius:2 }} />
              </div>
              <div className="pipeline-divider">
                <span className="pipeline-divider-label label-payer">🏛 INSURANCE COMPANY / PAYER SIDE</span>
                <div className="pipeline-divider-line" />
              </div>
            </div>
          )
        }

        return (
          <div key={idx}>
            {providerHeader}
            {handoffDivider}
            <div className="trace-row" onClick={() => setExpanded(isOpen ? null : idx)}>
              <div className="trace-icon" style={{ background: meta.bg }}>{meta.icon}</div>
              <div className="trace-name">{meta.label}</div>
              {agentBadge(agent, out)}
              <div className="trace-meta">
                <span>🕐 {ts}</span>
                {signal && <span>{signal}</span>}
              </div>
              <div className="trace-chevron">{isOpen ? '∨' : '›'}</div>
            </div>

            {isOpen && (
              <div className="expand-section" style={{ marginBottom:'0.5rem' }}>
                {isErr ? (
                  <div style={{ color:'var(--red-600)', fontSize:'.82rem' }}>
                    <strong>Error:</strong> {out.error || 'Unknown error'}
                    {out.traceback && (
                      <details style={{ marginTop:'.5rem' }}>
                        <summary style={{ cursor:'pointer', color:'var(--gray-500)' }}>View traceback</summary>
                        <pre style={{ fontSize:'.72rem', marginTop:'.5rem', whiteSpace:'pre-wrap', color:'var(--gray-700)' }}>{out.traceback}</pre>
                      </details>
                    )}
                  </div>
                ) : (
                  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'1rem' }}>
                    <div>
                      <div className="json-label">Input</div>
                      <div className="json-terminal-header">
                        <div className="json-dots">
                          <div className="json-dot" style={{ background:'#ff5f57' }} />
                          <div className="json-dot" style={{ background:'#febc2e' }} />
                          <div className="json-dot" style={{ background:'#28c840' }} />
                        </div>
                        <span className="json-terminal-title">↓ INPUT</span>
                      </div>
                      <div className="json-terminal-body">{JSON.stringify(entry.input_snapshot || {}, null, 2)}</div>
                    </div>
                    <div>
                      <div className="json-label">Output</div>
                      <div className="json-terminal-header">
                        <div className="json-dots">
                          <div className="json-dot" style={{ background:'#ff5f57' }} />
                          <div className="json-dot" style={{ background:'#febc2e' }} />
                          <div className="json-dot" style={{ background:'#28c840' }} />
                        </div>
                        <span className="json-terminal-title">↑ OUTPUT</span>
                      </div>
                      <div className="json-terminal-body">{JSON.stringify(out, null, 2)}</div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}
