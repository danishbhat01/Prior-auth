import { NavLink } from 'react-router-dom'

const TABS = [
  { to: '/overview',     icon: '📊', label: 'Overview' },
  { to: '/demo',         icon: '▶',  label: 'Live Demo' },
  { to: '/trust-safety', icon: '🛡️', label: 'Trust & Safety' },
  { to: '/audit',        icon: '🔍', label: 'Audit Log' },
  { to: '/review-queue', icon: '📋', label: 'Review Queue' },
]

export default function Navbar() {
  return (
    <nav className="navbar">
      <div className="navbar-logo">
        <div className="navbar-logo-icon">🏥</div>
        <div>
          <div className="navbar-logo-title">Prior Authorization AI</div>
          <div className="navbar-logo-sub">Multi-agent clinical workflow</div>
        </div>
      </div>

      <div className="navbar-tabs">
        {TABS.map(({ to, icon, label }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) => `navbar-tab${isActive ? ' active' : ''}`}
          >
            {icon} {label}
          </NavLink>
        ))}
      </div>

      <div className="navbar-right">
        <div className="live-badge">
          <div className="live-dot" />
          Live pipeline
        </div>
        <div style={{ fontSize: '1.1rem', cursor: 'pointer', color: 'var(--gray-400)' }}>🔔</div>
        <div className="navbar-avatar">VG</div>
      </div>
    </nav>
  )
}
