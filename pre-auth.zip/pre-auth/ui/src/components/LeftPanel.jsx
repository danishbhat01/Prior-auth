import { useEffect, useState } from 'react'

const API = 'http://localhost:8000'

// Specialties present in the current dataset.
const SPECIALTIES = [
  'Cardiology', 'Orthopedics', 'Oncology', 'Neurology', 'Gastroenterology', 'Rare Disease',
]

export default function LeftPanel({ form, onChange, onSubmit, loading }) {
  const [cases, setCases] = useState([])

  useEffect(() => {
    fetch(`${API}/api/cases`)
      .then(r => r.json())
      .then(data => setCases(Array.isArray(data) ? data : []))
      .catch(() => setCases([]))
  }, [])

  function handleSampleChange(e) {
    const pid = e.target.value
    const c = cases.find(x => x.patient_id === pid)
    if (!c) return
    onChange('patient_id', c.patient_id)
    onChange('policy_number', c.policy_number)
    onChange('contact_info', c.contact_information)
    onChange('specialty', c.specialty)
    onChange('doctor_note', c.doctor_note)
  }

  return (
    <aside className="left-panel">
      <div className="submit-title">📄 Submit a case</div>

      <div className="field-group">
        <label className="field-label">Load a case from dataset ({cases.length})</label>
        <select className="field-select" value={form.patient_id || ''} onChange={handleSampleChange}>
          <option value="">(select a real case, or enter manually)</option>
          {cases.map(c => (
            <option key={c.patient_id} value={c.patient_id}>
              {c.patient_id} · {c.specialty} · {c.policy_number}
            </option>
          ))}
        </select>
      </div>

      <div className="field-group">
        <label className="field-label">Specialty</label>
        <select
          className="field-select"
          value={form.specialty}
          onChange={e => onChange('specialty', e.target.value)}
        >
          {SPECIALTIES.map(s => <option key={s}>{s}</option>)}
        </select>
      </div>

      <div className="field-group">
        <label className="field-label">Case ID</label>
        <input
          className="field-input"
          placeholder="PA0112"
          value={form.patient_id}
          onChange={e => onChange('patient_id', e.target.value)}
        />
      </div>

      <div className="field-group">
        <label className="field-label">Policy Number</label>
        <input
          className="field-input"
          placeholder="P-032"
          value={form.policy_number}
          onChange={e => onChange('policy_number', e.target.value)}
        />
      </div>

      <div className="field-group">
        <label className="field-label">Contact Information</label>
        <input
          className="field-input"
          placeholder="email or phone"
          value={form.contact_info}
          onChange={e => onChange('contact_info', e.target.value)}
        />
      </div>

      <div className="field-group">
        <label className="field-label">Doctor's Note</label>
        <textarea
          className="field-textarea"
          placeholder="Paste the full clinical note here..."
          value={form.doctor_note}
          onChange={e => onChange('doctor_note', e.target.value)}
          rows={12}
        />
      </div>

      <button
        className="btn-primary"
        onClick={onSubmit}
        disabled={loading}
      >
        {loading ? <><span className="spinner" /> Running…</> : '▶  Run Pipeline'}
      </button>
    </aside>
  )
}
