import pandas as pd
from typing import List, Dict, Any
from pathlib import Path
from src.utils.logging import get_logger

logger = get_logger(__name__)

def load_doctor_notes(file_path: str) -> List[Dict[str, Any]]:
    """
    Loads doctor notes from an Excel file and returns them as a list of dictionaries.
    """
    path = Path(file_path)
    if not path.exists():
        logger.error(f"Dataset not found at {file_path}")
        raise FileNotFoundError(f"Dataset not found at {file_path}")
        
    logger.info(f"Loading doctor notes from {file_path}")
    try:
        df = pd.read_excel(file_path)
        notes = df.to_dict(orient="records")
        logger.info(f"Successfully loaded {len(notes)} notes.")
        return notes
    except Exception as e:
        logger.error(f"Failed to load notes from {file_path}: {e}")
        raise
