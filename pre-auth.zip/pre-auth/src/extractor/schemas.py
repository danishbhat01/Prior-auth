from pydantic import BaseModel, Field
from typing import List

class ExtractorOutput(BaseModel):
    """
    Structured output schema for the Extractor Agent.
    """
    diagnosis: List[str] = Field(default_factory=list, description="The primary diagnosis or impression(s). Must be a normalized base disease name without severity or laterality modifiers (e.g. 'Coronary artery disease' instead of 'severe triple-vessel CAD').")
    clinical_modifiers: List[str] = Field(default_factory=list, description="Severity, chronicity, laterality, or descriptive modifiers stripped from the raw diagnosis (e.g., 'refractory', 'severe', 'triple-vessel', 'left').")
    symptoms: List[str] = Field(default_factory=list, description="List of symptoms reported by the patient.")
    duration: str = Field(default="", description="Duration of symptoms or condition.")
    failed_treatments: List[str] = Field(default_factory=list, description="Treatments that have been tried and failed.")
    imaging: str = Field(default="", description="Findings from any imaging studies like MRI, CT, X-ray.")
    requested_procedure: List[str] = Field(default_factory=list, description="The procedure(s) being recommended or requested.")
