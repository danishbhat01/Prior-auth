from .schemas import ExtractorOutput
from .prompts import EXTRACTOR_SYSTEM_PROMPT, build_extractor_user_prompt
from src.llm.interfaces import BaseLLM
from src.utils.logging import get_logger

logger = get_logger(__name__)

class ExtractorAgent:
    """
    Agent responsible for extracting structured clinical information
    from unstructured doctor notes using an LLM.
    """
    
    def __init__(self, llm_client: BaseLLM):
        """
        Initializes the ExtractorAgent with a dependency-injected LLM client.
        """
        logger.info("Initializing ExtractorAgent (LLM Mode)")
        self.llm_client = llm_client
        
    def extract(self, specialty: str, note_text: str) -> ExtractorOutput:
        """
        Parses the input text and returns a structured ExtractorOutput.
        Note: Patient ID should NEVER be passed to this function.
        """
        if not note_text:
            logger.warning("Empty text provided for extraction.")
            return ExtractorOutput()
            
        logger.info(f"Extracting information from note (Specialty: {specialty})")
        
        user_prompt = build_extractor_user_prompt(specialty, note_text)
        
        try:
            output = self.llm_client.generate_structured(
                prompt=user_prompt,
                system_prompt=EXTRACTOR_SYSTEM_PROMPT,
                response_model=ExtractorOutput,
                max_retries=3
            )
            logger.info(f"Extraction complete: {output.model_dump()}")
            return output # type: ignore
        except Exception as e:
            logger.error(f"Extraction failed: {e}")
            raise
