import json
from src.llm.interfaces import BaseLLM
from src.utils.logging import get_logger
from src.form.schemas import PriorAuthForm
from src.policy.schemas import PolicyAnalysis
from src.critique.schemas import CritiqueReport
from .schemas import FinalAuthorizationDecision

logger = get_logger(__name__)

REVIEWER_SYSTEM_PROMPT = """
You are the final Insurer Review Agent in a medical prior authorization pipeline.

By the time a case reaches you, deterministic hard rules have ALREADY run and removed
the clear-cut outcomes: cases with unmet policy criteria were DENIED, and cases with a
critical QA failure or missing mandatory fields were routed to human review. You
therefore only ever see cases that have cleared every hard gate.

Perform a final, holistic review and choose between exactly two outcomes:

1. APPROVED — the clinical facts and the matched policy criteria fully and consistently
   support authorization. This is the expected outcome for a case that cleared every gate.

2. PENDING_REVIEW — you notice something a human should verify before approval: an
   internal inconsistency, weak or ambiguous clinical justification, a mismatch between
   the diagnosis/procedure and the cited criteria, or anything that does not sit right
   clinically. When genuinely in doubt, escalate rather than approve.

RULES:
1. You may NOT output DENIED. Denials are owned by the deterministic criteria engine, not by you.
2. Do NOT rubber-stamp. Only return APPROVED if the evidence actually supports it; otherwise escalate.
3. Base your reasoning ONLY on the provided Prior Authorization Form, Policy Analysis, and
   Critique Report. Never invent policy rules or clinical facts.
4. Your reasoning must explicitly cite the specific clinical facts and matched policy criteria
   behind your decision.
"""

class InsurerReviewAgent:
    """
    LLM-powered Agent that acts as the final decision maker.
    """
    
    def __init__(self, llm_client: BaseLLM):
        logger.info("Initializing InsurerReviewAgent (LLM Mode)")
        self.llm_client = llm_client
        
    def _apply_deterministic_rules(
        self,
        form: PriorAuthForm,
        critique: CritiqueReport,
    ) -> FinalAuthorizationDecision | None:
        """
        Returns a forced decision if any hard rule fires.
        Returns None if no rule applies — LLM reasoning proceeds normally.
        """
        # Rule 1: QA hard failure
        if critique.result == "FAIL" and critique.severity == "critical":
            return FinalAuthorizationDecision(
                decision="PENDING_REVIEW",
                reasoning="Critique QA returned a critical FAIL. Manual review required before submission.",
                rule_triggered="CRITIQUE_CRITICAL_FAIL",
            )

        # Rule 2: Missing policy criteria — always denied, no exceptions
        if form.policy_analysis.missing_criteria:
            return FinalAuthorizationDecision(
                decision="DENIED",
                reasoning=f"Authorization denied. The following required criteria were not met: "
                          f"{', '.join(form.policy_analysis.missing_criteria)}.",
                rule_triggered="MISSING_POLICY_CRITERIA",
            )

        # Rule 3: Critical information missing from form
        if not form.patient_id or not form.policy_number or not form.icd_coding_output.mappings:
            return FinalAuthorizationDecision(
                decision="PENDING_REVIEW",
                reasoning="Mandatory fields are missing. Case cannot be decided automatically.",
                rule_triggered="MISSING_MANDATORY_FIELDS",
            )

        return None  # No hard rule fired — proceed to LLM

    def review(self, 
               form: PriorAuthForm, 
               policy_analysis: PolicyAnalysis, 
               critique_report: CritiqueReport) -> FinalAuthorizationDecision:
               
        logger.info(f"Reviewing PriorAuthForm for patient_id: {form.patient_id}")
        
        forced_decision = self._apply_deterministic_rules(form, critique_report)
        if forced_decision:
            logger.info(f"Review completed via deterministic rule: DECISION={forced_decision.decision} RULE={forced_decision.rule_triggered}")
            return forced_decision

        
        user_prompt = f"""
## Prior Authorization Form:
{json.dumps(form.model_dump(), indent=2)}

## Policy Analysis:
{json.dumps(policy_analysis.model_dump(), indent=2)}

## Critique Report:
{json.dumps(critique_report.model_dump(), indent=2)}

Make the final authorization decision based on the rules. Return the FinalAuthorizationDecision schema.
"""
        try:
            output = self.llm_client.generate_structured(
                prompt=user_prompt,
                system_prompt=REVIEWER_SYSTEM_PROMPT,
                response_model=FinalAuthorizationDecision,
                max_retries=3
            )
            logger.info(f"Review complete: DECISION={output.decision}")
            return output # type: ignore
        except Exception as e:
            logger.error(f"Review failed: {e}")
            raise
