from typing import Literal
from pydantic import BaseModel, Field

class FinalAuthorizationDecision(BaseModel):
    """
    Final deterministic output from the Insurer Review Agent.
    """
    decision: Literal["APPROVED", "DENIED", "PENDING_REVIEW"] = Field(
        description="The final authorization decision."
    )
    reasoning: str = Field(
        description="Clear, detailed explanation for the decision, citing policy criteria and clinical facts."
    )
    rule_triggered: str | None = Field(
        default=None,
        description="The deterministic rule that triggered this decision, if any."
    )
