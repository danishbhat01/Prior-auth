"""
Payer-side pipeline.

Runs in the insurer's trust domain. It receives a *serialized* PriorAuthPackage
from the provider, re-validates it, reviews it with its OWN review agent and its
OWN LLM client, and records the outcome in its OWN inbox / decision store /
audit ledger — separate from the provider's audit trail.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone

from src.llm.azure import AzureOpenAILLM
from src.reviewer.agent import InsurerReviewAgent
from src.reviewer.schemas import FinalAuthorizationDecision
from src.utils.logging import get_logger

from .package import PriorAuthPackage, PAYER_INBOX, PAYER_DECISIONS, A2A_DIR

logger = get_logger(__name__)

PAYER_AUDIT_LOG = A2A_DIR / "payer_audit.jsonl"


class PayerReviewService:
    """The insurer side of the A2A boundary."""

    def __init__(self, llm_client=None):
        # The payer owns its own compute/agent — deliberately not shared with the provider.
        self.reviewer = InsurerReviewAgent(llm_client=llm_client or AzureOpenAILLM())

    def _payer_audit(self, correlation_id: str, event: str, payload: dict) -> None:
        PAYER_AUDIT_LOG.parent.mkdir(parents=True, exist_ok=True)
        entry = {
            "system": "payer",
            "correlation_id": correlation_id,
            "event": event,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "payload": payload,
        }
        with open(PAYER_AUDIT_LOG, "a") as f:
            f.write(json.dumps(entry) + "\n")

    def receive_and_review(self, package_json: str) -> FinalAuthorizationDecision:
        """
        Accept a serialized PriorAuthPackage (the A2A message), review it, and
        return the decision. All payer-side state is persisted independently.
        """
        # Cross the wire: deserialize + re-validate the incoming contract.
        package = PriorAuthPackage.model_validate_json(package_json)
        cid = package.correlation_id

        PAYER_INBOX.mkdir(parents=True, exist_ok=True)
        (PAYER_INBOX / f"{cid}.json").write_text(package.model_dump_json(indent=2))
        self._payer_audit(cid, "PackageReceived", {
            "from": package.submitting_system,
            "patient_id": package.patient_id,
            "policy_number": package.policy_number,
        })
        logger.info(f"[PAYER] Received prior-auth package for {package.patient_id} (corr {cid})")

        # Review using the payer's own agent. `form` carries policy_analysis internally.
        decision = self.reviewer.review(package.form, package.form.policy_analysis, package.critique)

        PAYER_DECISIONS.mkdir(parents=True, exist_ok=True)
        (PAYER_DECISIONS / f"{cid}.json").write_text(decision.model_dump_json(indent=2))
        self._payer_audit(cid, "DecisionIssued", {
            "decision": decision.decision,
            "rule_triggered": decision.rule_triggered,
        })
        logger.info(f"[PAYER] Decision for {package.patient_id}: {decision.decision}")
        return decision
