"""
The A2A message contract between the provider and payer pipelines.

`PriorAuthPackage` is the typed payload the provider submits to the payer — the
real-world analogue of an X12 278 prior-authorization request. It is serialized
to JSON at the provider outbox and deserialized (and re-validated) by the payer,
so the two sides only ever communicate through this contract, never shared memory.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from pydantic import BaseModel, Field

from src.form.schemas import PriorAuthForm
from src.critique.schemas import CritiqueReport

REPO_ROOT = Path(__file__).resolve().parents[2]
A2A_DIR = REPO_ROOT / "logs" / "a2a"
PROVIDER_OUTBOX = A2A_DIR / "provider_outbox"   # provider writes submitted packages here
PAYER_INBOX = A2A_DIR / "payer_inbox"           # payer records what it received
PAYER_DECISIONS = A2A_DIR / "payer_decisions"   # payer's own decision ledger


class PriorAuthPackage(BaseModel):
    """Typed prior-auth submission handed from provider -> payer (cf. X12 278 request)."""
    correlation_id: str
    patient_id: str
    policy_number: str
    specialty: str
    submitting_system: str = "provider"
    submitted_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    # The completed submission. `form` already embeds policy_analysis + icd_coding_output.
    form: PriorAuthForm
    critique: CritiqueReport


def submit_package(package: PriorAuthPackage) -> Path:
    """
    Provider-side 'send': serialize the package to the provider outbox and return
    the path. This serialization is the wire boundary — the payer reads it back
    independently.
    """
    PROVIDER_OUTBOX.mkdir(parents=True, exist_ok=True)
    path = PROVIDER_OUTBOX / f"{package.correlation_id}.json"
    path.write_text(package.model_dump_json(indent=2))
    return path
