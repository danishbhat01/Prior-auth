"""
A2A (agent-to-agent) boundary between the provider pipeline and the payer pipeline.

The provider side (extract -> code -> policy -> form -> critique) produces a typed
`PriorAuthPackage` and *submits* it. The payer side (`PayerReviewService`) receives
the serialized package, reviews it with its own agent, and records the outcome in
its own store — a real trust-domain boundary, not an in-process call.
"""
