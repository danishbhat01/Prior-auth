import json
import uuid
import os
from datetime import datetime, timezone
from typing import Any
from pathlib import Path

from src.utils.logging import get_logger

logger = get_logger(__name__)

REPO_ROOT = Path(__file__).resolve().parents[2]
LOGS_DIR = REPO_ROOT / "logs"

class AuditLogger:
    def __init__(self, case_id: str):
        self.case_id = case_id
        self.correlation_id = str(uuid.uuid4())
        self._entries: list[dict] = []
        
        if not LOGS_DIR.exists():
            LOGS_DIR.mkdir(parents=True, exist_ok=True)

    def log(self, agent: str, input_data: Any, output_data: Any, metadata: dict = {}):
        
        def serialize_pydantic(obj):
            if hasattr(obj, "model_dump"):
                return obj.model_dump()
            elif isinstance(obj, list):
                return [serialize_pydantic(item) for item in obj]
            elif isinstance(obj, dict):
                return {k: serialize_pydantic(v) for k, v in obj.items()}
            return obj

        self._entries.append({
            "case_id": self.case_id,
            "correlation_id": self.correlation_id,
            "agent": agent,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "input_snapshot": serialize_pydantic(input_data),
            "output_snapshot": serialize_pydantic(output_data),
            **metadata,
        })

    def flush(self):
        log_file = LOGS_DIR / "audit_log.jsonl"
        try:
            with open(log_file, "a") as f:
                for entry in self._entries:
                    f.write(json.dumps(entry) + "\n")
            self._entries.clear()
            logger.info(f"Audit log flushed for case {self.case_id} (correlation_id {self.correlation_id})")
        except Exception as e:
            logger.error(f"Failed to flush audit log for case {self.case_id}: {e}")
            raise
