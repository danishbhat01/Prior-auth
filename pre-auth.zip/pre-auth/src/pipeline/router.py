import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from src.icd.schemas import ICDCodingOutput
from src.policy.schemas import PolicyAnalysis
from src.critique.schemas import CritiqueReport
from src.utils.logging import get_logger

logger = get_logger(__name__)

REPO_ROOT = Path(__file__).resolve().parents[2]
LOGS_DIR = REPO_ROOT / "logs"
REVIEW_QUEUE_FILE = LOGS_DIR / "review_queue.json"

class PipelineRouter:
    """
    Central routing layer. Sits between each agent hand-off.
    Decides whether to continue, pause for human review, or raise.
    """

    def route_icd_output(self, icd_output: ICDCodingOutput, case_id: str) -> Literal["continue", "human_review"]:
        unresolved = [m for m in icd_output.mappings if m.status == "review_required"]
        if unresolved:
            self._queue_for_human_review(
                case_id=case_id,
                halt_agent="ICDCodingAgent",
                reason="ICD_REVIEW_REQUIRED",
                detail=f"Unresolved diagnoses: {[m.diagnosis for m in unresolved]}",
            )
            return "human_review"
        return "continue"

    def route_retrieval(self, policy_analysis: PolicyAnalysis, case_id: str) -> Literal["continue", "human_review"]:
        if policy_analysis.retrieval_confidence_summary == "low":
            self._queue_for_human_review(
                case_id=case_id,
                halt_agent="PolicyRetriever",
                reason="LOW_RETRIEVAL_CONFIDENCE",
                detail="Policy retriever returned only low-confidence chunks. Evidence is unreliable.",
            )
            return "human_review"
        return "continue"

    def route_critique(self, critique: CritiqueReport, case_id: str) -> Literal["continue", "human_review", "retry"]:
        if critique.result == "FAIL":
            if critique.severity == "critical":
                self._queue_for_human_review(
                    case_id=case_id,
                    halt_agent="CritiqueAgent",
                    reason="CRITIQUE_CRITICAL_FAIL", 
                    detail=str(critique.recommendations)
                )
                return "human_review"
            return "retry"   # non-critical: allow one re-run of the form filler + critique
        return "continue"

    def _queue_for_human_review(self, case_id: str, halt_agent: str, reason: str, detail: str):
        logger.warning(f"Routed to human review. Reason: {reason}. Detail: {detail}")
        
        queue_entry = {
            "case_id": case_id,
            "patient_id": case_id, # Simplified, using case_id as patient_id for now
            "halt_agent": halt_agent,
            "halt_reason": reason,
            "detail": detail,
            "queued_at": datetime.now(timezone.utc).isoformat(),
            "assigned_to": None
        }
        
        if not LOGS_DIR.exists():
            LOGS_DIR.mkdir(parents=True, exist_ok=True)
            
        # Read existing queue
        queue = []
        if REVIEW_QUEUE_FILE.exists():
            with open(REVIEW_QUEUE_FILE, "r") as f:
                try:
                    queue = json.load(f)
                except json.JSONDecodeError:
                    pass
                    
        # Filter out existing entries for the same case to avoid duplicates if re-run
        queue = [q for q in queue if q["case_id"] != case_id]
        queue.append(queue_entry)
        
        with open(REVIEW_QUEUE_FILE, "w") as f:
            json.dump(queue, f, indent=2)
