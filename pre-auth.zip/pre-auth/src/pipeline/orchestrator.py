import argparse
import json
from pathlib import Path
import traceback

from src.extractor.io import load_doctor_notes
from src.extractor.agent import ExtractorAgent
from src.llm.azure import AzureOpenAILLM
from src.icd.agent import ICDCodingAgent
from src.policy.retriever import PolicyRetriever
from src.policy.agent import PolicyAgent
from src.form.agent import FormFillerAgent
from src.critique.agent import CritiqueAgent
from src.pipeline.router import PipelineRouter
from src.pipeline.audit import AuditLogger
from src.pipeline.phi import mask_phi
from src.a2a.package import PriorAuthPackage, submit_package
from src.a2a.payer import PayerReviewService
from src.utils.logging import get_logger

logger = get_logger(__name__)

def run_pipeline(dataset_path: str, output_path: str, limit: int = 1):
    notes = load_doctor_notes(dataset_path)
    
    llm_client = AzureOpenAILLM()
    
    # Initialize agents
    extractor_agent = ExtractorAgent(llm_client=llm_client)
    icd_agent = ICDCodingAgent()
    policy_retriever = PolicyRetriever()
    policy_agent = PolicyAgent(llm_client=llm_client)
    form_filler = FormFillerAgent()
    critique_agent = CritiqueAgent(llm_client=llm_client)
    # Payer pipeline lives behind the A2A boundary — it owns its own review agent.
    payer_service = PayerReviewService()

    router = PipelineRouter()
    results = []
    
    for row in notes[:limit]:
        case_id = str(row.get("patient_id", "unknown"))
        specialty = row.get("specialty", "General")
        text = row.get("doctor_note", "")
        # Assuming policy_number exists in the dataset, defaulting for testing if missing
        policy_number = row.get("policy_number", "POL-001")
        contact_information = row.get("contact_information", "Unknown Contact")
        
        audit = AuditLogger(case_id=case_id)
        
        try:
            # 0. PHI Masking — runs BEFORE any LLM call. No raw identifier crosses
            # the LLM boundary; the audit entry itself carries only masked text.
            phi_result = mask_phi(text)
            audit.log(
                "PHIMasking",
                input_data={"raw_note_chars": len(text or "")},
                output_data={
                    "phi_masking_applied": True,
                    "masked_fields": phi_result.masked_fields,
                    "raw_phi_sent_to_llm": False,
                    "masked_note": phi_result.masked_text,
                },
            )

            # 1. Extractor (receives masked note only)
            extractor_input = {"specialty": specialty, "note_text": phi_result.masked_text}
            extractor_output = extractor_agent.extract(**extractor_input)
            audit.log("ExtractorAgent", input_data=extractor_input, output_data=extractor_output)
            
            # 2. ICD Coder
            icd_output = icd_agent.code(extractor_output, specialty)
            audit.log("ICDCodingAgent", input_data=extractor_output, output_data=icd_output)
            
            if router.route_icd_output(icd_output, case_id) == "human_review":
                results.append({"case_id": case_id, "status": "human_review", "reason": "ICD_REVIEW_REQUIRED"})
                audit.flush()
                continue
                
            # 3. Policy Retriever & Agent
            query = " ".join(extractor_output.diagnosis + extractor_output.requested_procedure)
            retrieved_chunks = policy_retriever.retrieve(policy_number=policy_number, query=query, k=3)
            audit.log("PolicyRetriever", input_data={"policy_number": policy_number, "query": query}, output_data=retrieved_chunks)
            
            policy_analysis = policy_agent.analyze(extractor_output, icd_output, retrieved_chunks)
            audit.log("PolicyAgent", input_data={"extractor_output": extractor_output, "icd_output": icd_output, "retrieved_chunks": retrieved_chunks}, output_data=policy_analysis)
            
            if router.route_retrieval(policy_analysis, case_id) == "human_review":
                results.append({"case_id": case_id, "status": "human_review", "reason": "LOW_RETRIEVAL_CONFIDENCE"})
                audit.flush()
                continue
                
            # 4. Form Filler
            form_input = {
                "patient_id": case_id,
                "contact_information": contact_information,
                "policy_number": policy_number,
                "specialty": specialty,
                "extractor_output": extractor_output,
                "icd_output": icd_output,
                "policy_analysis": policy_analysis
            }
            form = form_filler.fill(**form_input)
            audit.log("FormFillerAgent", input_data=form_input, output_data=form)
            
            # 5. Critique QA
            critique = critique_agent.critique(form)
            audit.log("CritiqueAgent", input_data=form, output_data=critique)
            
            route = router.route_critique(critique, case_id)
            if route == "human_review":
                results.append({"case_id": case_id, "status": "human_review", "reason": "CRITIQUE_CRITICAL_FAIL"})
                audit.flush()
                continue
                
            if route == "retry":
                # One retry
                logger.info(f"Retrying FormFiller and Critique for case {case_id}")
                form = form_filler.fill(**form_input)
                audit.log("FormFillerAgent", input_data=form_input, output_data=form, metadata={"attempt": 2})
                
                critique = critique_agent.critique(form)
                audit.log("CritiqueAgent", input_data=form, output_data=critique, metadata={"attempt": 2})
                
                if critique.result == "FAIL":
                    router._queue_for_human_review(case_id=case_id, halt_agent="CritiqueAgent", reason="CRITIQUE_RETRY_FAIL", detail=str(critique.recommendations))
                    results.append({"case_id": case_id, "status": "human_review", "reason": "CRITIQUE_RETRY_FAIL"})
                    audit.flush()
                    continue
            
            # 6. A2A boundary — provider submits the completed package to the payer.
            package = PriorAuthPackage(
                correlation_id=audit.correlation_id,
                patient_id=case_id,
                policy_number=policy_number,
                specialty=specialty,
                form=form,
                critique=critique,
            )
            submission_path = submit_package(package)
            audit.log(
                "PackageSubmitted",
                input_data={"submitting_system": "provider", "submission_path": str(submission_path)},
                output_data={"payer_endpoint": "PayerReviewService", "package_bytes": len(package.model_dump_json())},
            )

            # 7. Payer pipeline receives the serialized package and reviews independently.
            decision = payer_service.receive_and_review(package.model_dump_json())
            audit.log("InsurerReviewAgent", input_data={"received_package": True, "correlation_id": audit.correlation_id}, output_data=decision)

            results.append({
                "case_id": case_id,
                "status": "completed",
                "correlation_id": audit.correlation_id,
                "decision": decision.model_dump(),
                "final_form": form.model_dump()
            })
            
            audit.flush()
            
        except Exception as e:
            logger.error(f"Pipeline failed for case {case_id}: {e}\n{traceback.format_exc()}")
            audit.log("PipelineError", input_data={}, output_data={"error": str(e), "traceback": traceback.format_exc()})
            results.append({"case_id": case_id, "status": "error", "error": str(e)})
            audit.flush()
            
    out_path = Path(output_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(results, f, indent=4)
        
    logger.info(f"Pipeline execution completed. Results saved to {output_path}")

class PipelineResult:
    def __init__(self, status: str, correlation_id: str, case_id: str, reason: str = None, error: str = None):
        self.status = status
        self.correlation_id = correlation_id
        self.case_id = case_id
        self.reason = reason
        self.error = error

def run_pipeline_single(patient_id: str, policy_number: str, contact_info: str, doctor_note: str, specialty: str = "General") -> PipelineResult:
    llm_client = AzureOpenAILLM()
    extractor_agent = ExtractorAgent(llm_client=llm_client)
    icd_agent = ICDCodingAgent()
    policy_retriever = PolicyRetriever()
    policy_agent = PolicyAgent(llm_client=llm_client)
    form_filler = FormFillerAgent()
    critique_agent = CritiqueAgent(llm_client=llm_client)
    # Payer pipeline lives behind the A2A boundary — it owns its own review agent.
    payer_service = PayerReviewService()
    router = PipelineRouter()

    case_id = patient_id
    audit = AuditLogger(case_id=case_id)
    
    try:
        # 0. PHI Masking — runs BEFORE any LLM call. No raw identifier crosses
        # the LLM boundary; the audit entry itself carries only masked text.
        phi_result = mask_phi(doctor_note)
        masked_note = phi_result.masked_text
        audit.log(
            "PHIMasking",
            input_data={"raw_note_chars": len(doctor_note or "")},
            output_data={
                "phi_masking_applied": True,
                "masked_fields": phi_result.masked_fields,
                "raw_phi_sent_to_llm": False,
                "masked_note": masked_note,
            },
        )

        # 1. Extractor (receives masked note only)
        extractor_input = {"specialty": specialty, "note_text": masked_note}
        extractor_output = extractor_agent.extract(**extractor_input)
        audit.log("ExtractorAgent", input_data=extractor_input, output_data=extractor_output)
        
        # 2. ICD Coder
        icd_output = icd_agent.code(extractor_output, specialty)
        audit.log("ICDCodingAgent", input_data=extractor_output, output_data=icd_output)
        
        if router.route_icd_output(icd_output, case_id) == "human_review":
            audit.flush()
            return PipelineResult("PENDING_REVIEW", audit.correlation_id, case_id, reason="ICD_REVIEW_REQUIRED")
            
        # 3. Policy Retriever & Agent
        query = " ".join(extractor_output.diagnosis + extractor_output.requested_procedure)
        retrieved_chunks = policy_retriever.retrieve(policy_number=policy_number, query=query, k=3)
        audit.log("PolicyRetriever", input_data={"policy_number": policy_number, "query": query}, output_data=retrieved_chunks)
        
        policy_analysis = policy_agent.analyze(extractor_output, icd_output, retrieved_chunks)
        audit.log("PolicyAgent", input_data={"extractor_output": extractor_output, "icd_output": icd_output, "retrieved_chunks": retrieved_chunks}, output_data=policy_analysis)
        
        if router.route_retrieval(policy_analysis, case_id) == "human_review":
            audit.flush()
            return PipelineResult("PENDING_REVIEW", audit.correlation_id, case_id, reason="LOW_RETRIEVAL_CONFIDENCE")
            
        # 4. Form Filler
        form_input = {
            "patient_id": case_id,
            "contact_information": contact_info,
            "policy_number": policy_number,
            "specialty": specialty,
            "extractor_output": extractor_output,
            "icd_output": icd_output,
            "policy_analysis": policy_analysis
        }
        form = form_filler.fill(**form_input)
        audit.log("FormFillerAgent", input_data=form_input, output_data=form)
        
        # 5. Critique QA
        critique = critique_agent.critique(form)
        audit.log("CritiqueAgent", input_data=form, output_data=critique)
        
        route = router.route_critique(critique, case_id)
        if route == "human_review":
            audit.flush()
            return PipelineResult("PENDING_REVIEW", audit.correlation_id, case_id, reason="CRITIQUE_CRITICAL_FAIL")
            
        if route == "retry":
            # Pass critique recommendations back into the note so the extractor/filler can correct itself
            logger.info(f"Retrying pipeline for case {case_id} with critique feedback")
            critique_feedback = "\n".join(f"- {r}" for r in critique.recommendations)
            # Re-extract from the MASKED note (never the raw note) to preserve the PHI boundary.
            enriched_note = f"{masked_note}\n\n[QA Critique Feedback for Correction]:\n{critique_feedback}"
            extractor_input_retry = {"specialty": specialty, "note_text": enriched_note}
            extractor_output_retry = extractor_agent.extract(**extractor_input_retry)
            form_input_retry = {**form_input, "extractor_output": extractor_output_retry}
            
            form = form_filler.fill(**form_input_retry)
            audit.log("FormFillerAgent", input_data=form_input_retry, output_data=form, metadata={"attempt": 2, "critique_feedback": critique_feedback})
            
            critique = critique_agent.critique(form)
            audit.log("CritiqueAgent", input_data=form, output_data=critique, metadata={"attempt": 2})
            
            if critique.result == "FAIL":
                router._queue_for_human_review(case_id=case_id, halt_agent="CritiqueAgent", reason="CRITIQUE_RETRY_FAIL", detail=str(critique.recommendations))
                audit.flush()
                return PipelineResult("PENDING_REVIEW", audit.correlation_id, case_id, reason="CRITIQUE_RETRY_FAIL")
        
        # 6. A2A boundary — provider submits the completed package to the payer.
        package = PriorAuthPackage(
            correlation_id=audit.correlation_id,
            patient_id=case_id,
            policy_number=policy_number,
            specialty=specialty,
            form=form,
            critique=critique,
        )
        submission_path = submit_package(package)
        audit.log(
            "PackageSubmitted",
            input_data={"submitting_system": "provider", "submission_path": str(submission_path)},
            output_data={"payer_endpoint": "PayerReviewService", "package_bytes": len(package.model_dump_json())},
        )

        # 7. Payer pipeline receives the serialized package and reviews independently.
        decision = payer_service.receive_and_review(package.model_dump_json())
        audit.log("InsurerReviewAgent", input_data={"received_package": True, "correlation_id": audit.correlation_id}, output_data=decision)
        audit.flush()

        return PipelineResult(decision.decision, audit.correlation_id, case_id)
        
    except Exception as e:
        logger.error(f"Pipeline failed for case {case_id}: {e}\n{traceback.format_exc()}")
        audit.log("PipelineError", input_data={}, output_data={"error": str(e), "traceback": traceback.format_exc()})
        audit.flush()
        return PipelineResult("ERROR", audit.correlation_id, case_id, error=str(e))

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run full Pre-Auth Pipeline")
    parser.add_argument("--dataset", type=str, required=True, help="Path to doctor notes excel file")
    parser.add_argument("--output", type=str, required=True, help="Path to save output json")
    parser.add_argument("--limit", type=int, default=1, help="Max number of cases to process")
    args = parser.parse_args()
    
    run_pipeline(args.dataset, args.output, args.limit)
