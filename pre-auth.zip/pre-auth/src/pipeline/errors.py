from typing import List

class PipelineError(Exception):
    """Base class for all pipeline errors."""
    pass

class LowRetrievalConfidenceError(PipelineError):
    pass

class ICDReviewRequiredError(PipelineError):
    def __init__(self, case_id: str, unresolved_diagnoses: List[str]):
        self.case_id = case_id
        self.unresolved_diagnoses = unresolved_diagnoses
        super().__init__(f"Case {case_id} requires ICD review for diagnoses: {unresolved_diagnoses}")

class CritiqueFatalError(PipelineError):
    pass

class MandatoryFieldMissingError(PipelineError):
    def __init__(self, missing_fields: List[str]):
        self.missing_fields = missing_fields
        super().__init__(f"Mandatory fields missing: {missing_fields}")
