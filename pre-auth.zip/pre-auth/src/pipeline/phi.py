"""
PHI Masking Layer.

Runs BEFORE any doctor note is handed to an LLM. Direct identifiers (name, DOB,
phone, email, MRN, SSN, address) are replaced with typed placeholders so that no
raw PHI ever crosses the LLM boundary.

Design constraints:
- Deterministic, no LLM, no network. This is a compliance control, so it must be
  auditable and reproducible.
- Conservative on clinical text: patterns are written to avoid masking clinical
  numbers such as "64-year-old", "18 months", "90% LAD stenosis" or ICD codes
  like "M17.11".
- Returns the ordered set of field *types* actually masked, for the audit trace.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from src.utils.logging import get_logger

logger = get_logger(__name__)


@dataclass
class PHIMaskResult:
    """Outcome of masking a single free-text note."""
    masked_text: str
    masked_fields: list[str] = field(default_factory=list)

    @property
    def phi_detected(self) -> bool:
        return bool(self.masked_fields)


# Rule order matters: e-mail and DOB are masked before phone so the phone rule
# never chews into an address token or a date. Each rule is (field_type, regex,
# replacement). `replacement` may reference groups; the label group is preserved.
_RULES: list[tuple[str, re.Pattern, str]] = [
    # Email: local@domain.tld
    (
        "email",
        re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}"),
        "[EMAIL]",
    ),
    # SSN: 123-45-6789
    (
        "ssn",
        re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
        "[SSN]",
    ),
    # Name following an explicit label ("Patient: Anita Sharma", "Name - John Doe").
    # Requires at least two capitalised tokens so it never fires on
    # "Patient is a 64-year-old female".
    (
        "patient_name",
        re.compile(
            r"(?i)\b(patient|name|pt)\b\s*[:\-]\s*"
            r"([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)"
        ),
        r"\1: [PATIENT_NAME]",
    ),
    # Name in narrative form with no colon ("Patient Vikram Iyer, ...", "Patient
    # Layla Gonzalez is a ..."). Requires two Capitalised tokens right after
    # "Patient", so "Patient is a 71-year-old male" (lowercase) never matches.
    (
        "patient_name",
        re.compile(r"\bPatient\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)"),
        "Patient [PATIENT_NAME]",
    ),
    # Street address in narrative form ("residing at 394 Oak Ave, Miami, phone ...").
    # Non-greedy up to the next field (phone / "is a" / DOB) or sentence end.
    (
        "address",
        re.compile(r"(?i)\bresiding at\s+.+?(?=,\s*phone|,\s*is\b|,\s*DOB|\.)"),
        "residing at [ADDRESS]",
    ),
    # Date of birth: "DOB 04-Jan-1962", "D.O.B: 4/1/1962", "date of birth Jan 4, 1962".
    (
        "dob",
        re.compile(
            r"(?i)\b(DOB|D\.O\.B\.?|date of birth)\b\s*[:\-]?\s*"
            r"(\d{1,2}[-/][A-Za-z]{3,9}[-/]\d{2,4}"
            r"|\d{1,2}[-/]\d{1,2}[-/]\d{2,4}"
            r"|[A-Za-z]{3,9}\s+\d{1,2},?\s+\d{4})"
        ),
        r"\1 [DOB]",
    ),
    # MRN: "MRN: A12345", "MRN 0099887"
    (
        "mrn",
        re.compile(r"(?i)\bMRN\b\s*[:#\-]?\s*([A-Za-z0-9\-]{3,})"),
        "MRN [MRN]",
    ),
    # Address on an explicit label line ("Address: 12 Baker St, London").
    (
        "address",
        re.compile(r"(?i)\bAddress\b\s*[:\-]\s*([^\n]+)"),
        "Address: [ADDRESS]",
    ),
    # Phone: 7+ dial characters bounded by non-digits. Runs last so labelled
    # dates/MRNs are already gone. Requires a run of digit/sep chars so it will
    # not match "64" or "18 months".
    (
        "phone",
        re.compile(r"(?<![\w])(\+?\d[\d\-\s().]{6,}\d)(?![\w])"),
        "[PHONE]",
    ),
]


def mask_phi(text: str | None) -> PHIMaskResult:
    """
    Replace direct identifiers in `text` with typed placeholders.

    Returns a `PHIMaskResult` carrying the masked text and the ordered, unique
    list of field types that were actually masked. Safe to log (contains no raw
    PHI).
    """
    if not text:
        return PHIMaskResult(masked_text=text or "", masked_fields=[])

    masked = text
    masked_fields: list[str] = []

    for field_type, pattern, replacement in _RULES:
        new_masked, n = pattern.subn(replacement, masked)
        if n > 0 and field_type not in masked_fields:
            masked_fields.append(field_type)
        masked = new_masked

    if masked_fields:
        logger.info(f"PHI masked before LLM call: fields={masked_fields}")
    else:
        logger.info("PHI masking ran; no direct identifiers detected in note.")

    return PHIMaskResult(masked_text=masked, masked_fields=masked_fields)
