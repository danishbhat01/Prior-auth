from typing import List, Literal
from pydantic import BaseModel, Field

class PolicyAnalysis(BaseModel):
    """
    LLM output representing the interpretation of policy against patient clinical facts.
    """
    policy_summary: str = Field(description="Brief summary of the relevant policy criteria.")
    met_criteria: List[str] = Field(default_factory=list, description="List of policy criteria that the patient clearly meets.")
    missing_criteria: List[str] = Field(default_factory=list, description="List of policy criteria that the patient fails to meet or for which there is insufficient evidence.")
    supporting_policy_sections: List[str] = Field(default_factory=list, description="Direct quotes or specific sections from the policy document supporting this analysis.")
    retrieval_confidence_summary: Literal["high", "medium", "low"] = Field(description="The worst-case retrieval confidence across all evaluated policy chunks.")
