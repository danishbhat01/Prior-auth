import pandas as pd
from typing import List, Dict, Any
from pathlib import Path

import faiss
import numpy as np
from pydantic import BaseModel
from sentence_transformers import SentenceTransformer
from typing import Literal

from src.utils.logging import get_logger
from src.pipeline.errors import LowRetrievalConfidenceError

logger = get_logger(__name__)

REPO_ROOT = Path(__file__).resolve().parents[2]
POLICY_DATASET_PATH = REPO_ROOT / "Dataset" / "policies" / "policy_dataset.xlsx"

class PolicyChunk(BaseModel):
    chunk_id: str
    text: str
    similarity_score: float
    retrieval_confidence: Literal["high", "medium", "low"]


class PolicyRetriever:
    """
    Modular RAG Retriever using FAISS and sentence-transformers.
    Performs deterministic lookup by policy_number, then semantic retrieval within that policy.
    """
    def __init__(self, model_name: str = "pritamdeka/S-PubMedBert-MS-MARCO"):
        logger.info(f"Initializing PolicyRetriever with model {model_name}")
        self.encoder = SentenceTransformer(model_name)
        self.df = pd.read_excel(POLICY_DATASET_PATH)

    def _chunk_text(self, text: str, max_chars: int = 500) -> List[str]:
        """Simple chunker by paragraphs or max_chars."""
        paragraphs = [p.strip() for p in text.split("\n") if p.strip()]
        chunks = []
        current_chunk = ""
        for p in paragraphs:
            if len(current_chunk) + len(p) < max_chars:
                current_chunk += p + " "
            else:
                if current_chunk:
                    chunks.append(current_chunk.strip())
                current_chunk = p + " "
        if current_chunk:
            chunks.append(current_chunk.strip())
        return chunks

    def retrieve(self, policy_number: str, query: str, k: int = 3) -> List[PolicyChunk]:
        """
        1. Find policy by policy_number
        2. Chunk document
        3. Index in FAISS
        4. Return top-k chunks
        """
        logger.info(f"Retrieving policy chunks for policy_number: {policy_number}")
        
        # 1. Deterministic Lookup
        matched = self.df[self.df["policy_number"] == policy_number]
        if matched.empty:
            logger.error(f"Policy number {policy_number} not found in dataset.")
            return []
            
        row = matched.iloc[0]
        document = row["policy_document"]
        specialty = row["specialty"]
        
        if pd.isna(document) or not str(document).strip():
            logger.warning(f"Policy {policy_number} has an empty document.")
            return []

        # 2. Chunking
        doc_chunks = self._chunk_text(str(document))
        if not doc_chunks:
            return []
            
        chunks_data = []
        all_texts = []
        for i, chunk in enumerate(doc_chunks):
            chunks_data.append({
                "policy_number": policy_number,
                "specialty": specialty,
                "content": chunk,
                "chunk_id": i
            })
            all_texts.append(chunk)
            
        # 3. Indexing
        embeddings = self.encoder.encode(all_texts, convert_to_numpy=True, normalize_embeddings=True)
        dimension = embeddings.shape[1]
        index = faiss.IndexFlatL2(dimension)
        index.add(embeddings)
        
        # 4. Retrieval
        query_emb = self.encoder.encode([query], convert_to_numpy=True, normalize_embeddings=True)
        distances, indices = index.search(query_emb, min(k, index.ntotal))
        
        results = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx != -1:
                chunk_info = chunks_data[idx]
                
                # We use 1.0 / (1.0 + dist) to map L2 distance to a cosine-like similarity score
                similarity = 1.0 / (1.0 + float(dist))
                
                if similarity >= 0.82:
                    confidence = "high"
                elif similarity >= 0.65:
                    confidence = "medium"
                else:
                    confidence = "low"
                    
                chunk = PolicyChunk(
                    chunk_id=str(chunk_info["chunk_id"]),
                    text=chunk_info["content"],
                    similarity_score=similarity,
                    retrieval_confidence=confidence
                )
                results.append(chunk)
                
        if results and all(c.retrieval_confidence == "low" for c in results):
            logger.error("All retrieved chunks have low confidence.")
            raise LowRetrievalConfidenceError("All retrieved policy chunks returned low confidence.")
                
        return results
