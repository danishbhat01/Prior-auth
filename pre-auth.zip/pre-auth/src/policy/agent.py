import json
from typing import List, Dict, Any

from src.extractor.schemas import ExtractorOutput
from src.icd.schemas import ICDCodingOutput
from src.llm.interfaces import BaseLLM
from src.utils.logging import get_logger

from .schemas import PolicyAnalysis
from .retriever import PolicyChunk

logger = get_logger(__name__)

POLICY_AGENT_SYSTEM_PROMPT = """
You are a precise, objective Policy Interpretation Agent for a medical prior authorization pipeline.
Your ONLY job is to compare the patient's structured clinical facts against the provided medical policy text and determine which criteria are met and which are missing.

RULES:
1. Base your analysis STRICTLY on the retrieved policy context provided. Do NOT use outside medical knowledge to invent criteria.
2. Cross-reference the policy against the patient's Extractor Output (diagnoses, modifiers, symptoms, failed treatments, imaging, requested procedures) and the mapped ICD codes.
3. You MUST NOT make the final authorization decision (do NOT output APPROVED or DENIED). That is handled by a deterministic rules engine.
4. If a criteria is explicitly required by the policy but the patient's facts do not mention it, list it in `missing_criteria`.
5. If the patient's facts explicitly satisfy a criteria, list it in `met_criteria`.
6. Extract exact quotes from the retrieved chunks into `supporting_policy_sections` to prove your analysis.
7. Output strictly in the requested JSON schema format.
"""

class PolicyAgent:
    """
    LLM-powered Agent that interprets retrieved policy chunks against a patient's clinical profile.
    """
    
    def __init__(self, llm_client: BaseLLM):
        logger.info("Initializing PolicyAgent (LLM Mode)")
        self.llm_client = llm_client
        
    def analyze(self, 
                extractor_output: ExtractorOutput, 
                icd_output: ICDCodingOutput, 
                retrieved_chunks: List[PolicyChunk]) -> PolicyAnalysis:
        
        logger.info("Analyzing policy against patient facts...")
        
        # Combine retrieved chunks into a single context string
        policy_context = "\n\n".join([f"[Confidence: {c.retrieval_confidence}]\n{c.text}" for c in retrieved_chunks])
        if not policy_context.strip():
            logger.warning("No policy context retrieved. Returning empty analysis.")
            return PolicyAnalysis(
                policy_summary="No relevant policy found for the given specialty and condition.",
                met_criteria=[],
                missing_criteria=["No policy found to evaluate against."],
                retrieval_confidence_summary="low"
            )
            
        user_prompt = f"""
## Retrieved Policy Guidelines:
{policy_context}

## Patient Clinical Profile:
{json.dumps(extractor_output.model_dump(), indent=2)}

## ICD Mappings:
{json.dumps(icd_output.model_dump(), indent=2)}

Please analyze the clinical profile against the policy guidelines and return the PolicyAnalysis schema.
"""
        
        try:
            output = self.llm_client.generate_structured(
                prompt=user_prompt,
                system_prompt=POLICY_AGENT_SYSTEM_PROMPT,
                response_model=PolicyAnalysis,
                max_retries=3
            )
            logger.info(f"Policy Analysis complete: {output.model_dump()}")
            return output # type: ignore
        except Exception as e:
            logger.error(f"Policy Analysis failed: {e}")
            raise
