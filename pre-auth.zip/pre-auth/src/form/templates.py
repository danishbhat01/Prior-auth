"""
Form template lookup.

Minimal use of Dataset/forms/prior_auth_form_templates.xlsx: resolve which insurer
+ template applies to a case, keyed by specialty. (Full per-field template
validation is intentionally out of scope for now.)
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import pandas as pd

from src.utils.logging import get_logger

logger = get_logger(__name__)

REPO_ROOT = Path(__file__).resolve().parents[2]
FORMS_PATH = REPO_ROOT / "Dataset" / "forms" / "prior_auth_form_templates.xlsx"

_DEFAULT_INSURER = "Standard Commercial Payer"
_DEFAULT_TEMPLATE = "T01_Standard_Commercial"


@lru_cache(maxsize=1)
def _specialty_map() -> dict[str, tuple[str, str]]:
    """{normalized specialty -> (template_id, insurer_name)} from the templates file."""
    try:
        df = pd.read_excel(FORMS_PATH)
    except Exception as e:  # missing/corrupt file must not crash the pipeline
        logger.warning(f"Could not load form templates ({e}); defaulting to Standard Commercial.")
        return {}
    mapping: dict[str, tuple[str, str]] = {}
    for _, row in df.iterrows():
        specialty = str(row.get("specialty", "")).strip().lower()
        if not specialty or specialty in mapping:
            continue
        mapping[specialty] = (
            str(row.get("template_id", _DEFAULT_TEMPLATE)).strip(),
            str(row.get("insurer_name", _DEFAULT_INSURER)).strip(),
        )
    return mapping


def resolve_template(specialty: str) -> tuple[str, str]:
    """
    Return (template_id, insurer_name) for a case's specialty. Falls back to the
    generic 'Any' template, then to Standard Commercial if nothing matches.
    """
    mapping = _specialty_map()
    key = (specialty or "").strip().lower()
    if key in mapping:
        return mapping[key]
    if "any" in mapping:
        return mapping["any"]
    return (_DEFAULT_TEMPLATE, _DEFAULT_INSURER)
