from src.extractor.schemas import ExtractorOutput
from src.icd.schemas import ICDCodingOutput
from src.policy.schemas import PolicyAnalysis
from src.utils.logging import get_logger
from .schemas import PriorAuthForm
from .templates import resolve_template

logger = get_logger(__name__)

class FormFillerAgent:
    """
    Deterministic Agent that populates the PriorAuthForm from fragmented inputs.
    """
    
    def __init__(self):
        logger.info("Initializing FormFillerAgent (Deterministic Mode)")
        
    def fill(self, 
             patient_id: str, 
             contact_information: str, 
             policy_number: str, 
             specialty: str,
             extractor_output: ExtractorOutput,
             icd_output: ICDCodingOutput,
             policy_analysis: PolicyAnalysis) -> PriorAuthForm:
             
        logger.info(f"Populating PriorAuthForm for patient_id: {patient_id}")

        # Invariant check
        if policy_analysis.met_criteria:
            if not policy_analysis.supporting_policy_sections:
                logger.warning(f"Invariant violated for patient {patient_id}: met_criteria is non-empty but supporting_policy_sections is empty.")

        # Resolve the insurer + form template for this specialty (from the forms dataset).
        template_id, insurer_name = resolve_template(specialty)
        logger.info(f"Form template for '{specialty}': {template_id} ({insurer_name})")

        return PriorAuthForm(
            patient_id=patient_id,
            contact_information=contact_information,
            policy_number=policy_number,
            specialty=specialty,
            insurer_name=insurer_name,
            form_template_id=template_id,
            diagnosis=extractor_output.diagnosis or [],
            clinical_modifiers=extractor_output.clinical_modifiers or [],
            symptoms=extractor_output.symptoms or [],
            failed_treatments=extractor_output.failed_treatments or [],
            imaging=extractor_output.imaging or "",
            requested_procedure=extractor_output.requested_procedure or [],
            policy_analysis=policy_analysis,
            icd_coding_output=icd_output
        )
