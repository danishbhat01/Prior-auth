from typing import List, Optional
from pydantic import BaseModel, Field

from src.policy.schemas import PolicyAnalysis
from src.icd.schemas import ICDCodingOutput

class PriorAuthForm(BaseModel):
    """
    The unified Pydantic schema representing the final populated Prior Authorization Form.
    This serves as the single source of truth for the completed submission package.
    """
    # Patient Information
    patient_id: str
    contact_information: str
    
    # Insurance Information
    policy_number: str
    specialty: str
    insurer_name: str = ""
    form_template_id: str = ""
    
    # Clinical Information
    diagnosis: List[str]
    clinical_modifiers: List[str]
    symptoms: List[str]
    failed_treatments: List[str]
    imaging: str
    
    # Authorization Request
    requested_procedure: List[str]
    
    # Embedded Outputs
    policy_analysis: PolicyAnalysis
    icd_coding_output: ICDCodingOutput
