from typing import Type, get_type_hints
from pydantic import BaseModel, ValidationError


def coerce_list_str_fields(instance: BaseModel, model: Type[BaseModel]) -> None:
    """
    Defensive helper: for every field declared as List[str] on the Pydantic model,
    force-coerce the parsed value to a list of strings. Raises ValidationError if
    a field is a non-iterable scalar (e.g. the LLM returned a bare string).
    """
    hints = get_type_hints(model)
    model_fields = model.model_fields
    for field_name in model_fields.keys():
        annotation = hints.get(field_name)
        if annotation is None:
            continue
        origin = getattr(annotation, "__origin__", None)
        if origin is list:
            current = getattr(instance, field_name)
            if current is None:
                setattr(instance, field_name, [])
                continue
            if isinstance(current, (str, bytes, int, float, bool)):
                raise ValidationError.from_exception_data(
                    title=model.__name__,
                    line_errors=[{
                        "type": "value_error",
                        "loc": (field_name,),
                        "msg": (
                            f"Expected JSON array of strings for '{field_name}', "
                            f"got scalar {type(current).__name__}: {current!r}"
                        ),
                    }],
                )
            coerced = [str(x) for x in current]
            setattr(instance, field_name, coerced)


def summarize_field_types(instance: BaseModel, model: Type[BaseModel]) -> str:
    """Compact type summary for logging, e.g. diagnosis=<list[str]> symptoms=<list[str]>."""
    parts: list[str] = []
    for field_name in model.model_fields.keys():
        value = getattr(instance, field_name)
        if isinstance(value, list):
            inner = type(value[0]).__name__ if value else "empty"
            parts.append(f"{field_name}=<list[{inner}]>")
        else:
            parts.append(f"{field_name}=<{type(value).__name__}>")
    return " ".join(parts)
