import os
import time
import json
from typing import Type
from pydantic import BaseModel, ValidationError
from google import genai
from google.genai import types
from dotenv import load_dotenv

from .interfaces import BaseLLM
from .response_validation import coerce_list_str_fields, summarize_field_types
from src.utils.logging import get_logger

logger = get_logger(__name__)

# Ensure env variables are loaded
load_dotenv()

class GeminiLLM(BaseLLM):
    """
    Gemini LLM implementation using the official google-genai SDK.
    """
    
    def __init__(self, model_name: str = "gemini-2.5-flash"):
        self.api_key = os.getenv("GEMINI_API_KEY")
        self.model_name = model_name
        
        if not self.api_key:
            logger.warning("GEMINI_API_KEY environment variable is missing. Initialization may fail.")
            
        self.client = genai.Client(api_key=self.api_key)

    def generate_structured(
        self,
        prompt: str,
        system_prompt: str,
        response_model: Type[BaseModel],
        max_retries: int = 3
    ) -> BaseModel:
        
        attempt = 0
        current_prompt = prompt
        
        while attempt < max_retries:
            attempt += 1
            start_time = time.time()
            
            try:
                logger.info(f"LLM Call Attempt {attempt}/{max_retries} to model: {self.model_name}")
                
                # Using structured outputs from google-genai
                response = self.client.models.generate_content(
                    model=self.model_name,
                    contents=[
                        types.Content(role="user", parts=[
                            types.Part.from_text(text=f"System Instructions:\n{system_prompt}\n\nUser Request:\n{current_prompt}")
                        ])
                    ],
                    config=types.GenerateContentConfig(
                        response_mime_type="application/json",
                        response_schema=response_model, # Pass Pydantic model directly
                        temperature=0.0
                    )
                )
                
                latency = time.time() - start_time
                
                # Try to parse the usage data if available
                tokens = "unknown"
                if hasattr(response, "usage_metadata") and response.usage_metadata:
                    tokens = response.usage_metadata.total_token_count
                    
                logger.info(f"LLM Response - Model: {self.model_name}, Latency: {latency:.2f}s, Tokens: {tokens}, Status: Success")
                
                if not response.text:
                     raise ValidationError.from_exception_data(
                        title="LLMParsingError",
                        line_errors=[{"type": "value_error", "loc": ("response",), "msg": "Response text is empty"}]
                    )

                # Parse the JSON string into the Pydantic model
                parsed_output = response_model.model_validate_json(response.text)

                # Defensive post-validation: coerce every List[str] field to actual list of strings.
                # Some LLM providers may coerce arrays to bare strings; this guard keeps the
                # contract explicit and surfaces a clean ValidationError for the retry loop.
                coerce_list_str_fields(parsed_output, response_model)

                logger.info(
                    f"LLM Field-Types - Model: {self.model_name}, "
                    f"Types: {summarize_field_types(parsed_output, response_model)}"
                )

                return parsed_output

            except ValidationError as e:
                latency = time.time() - start_time
                logger.warning(f"LLM Response - Latency: {latency:.2f}s, Status: Validation Failed - {e}")
                
                if attempt >= max_retries:
                    logger.error("Max retries reached. Failing.")
                    raise
                    
                # Append validation errors to the prompt for the next attempt
                error_msg = f"Your previous response failed schema validation. Please correct the following errors:\n{str(e)}\n\nOriginal request:\n{prompt}"
                current_prompt = error_msg
                
            except Exception as e:
                latency = time.time() - start_time
                logger.error(f"LLM Response - Latency: {latency:.2f}s, Status: Error - {e}")
                raise
