import os
import time
import json
import random
from typing import Type
from pydantic import BaseModel, ValidationError
from openai import (
    AzureOpenAI,
    APIConnectionError,
    APITimeoutError,
    InternalServerError,
    RateLimitError,
)
from dotenv import load_dotenv

from .interfaces import BaseLLM
from .response_validation import coerce_list_str_fields, summarize_field_types
from src.utils.logging import get_logger

logger = get_logger(__name__)

# Ensure env variables are loaded
load_dotenv()

# Transient failures worth retrying with backoff (rate limits, timeouts, 5xx).
# Distinct from ValidationError, which is retried by re-prompting the model.
TRANSIENT_LLM_ERRORS = (
    RateLimitError,
    APITimeoutError,
    APIConnectionError,
    InternalServerError,
)

class AzureOpenAILLM(BaseLLM):
    """
    Azure OpenAI LLM implementation using the openai python SDK.
    """
    
    def __init__(self, model_name: str = None):
        # We allow model_name override, but default to the env var deployment name
        self.deployment_name = model_name or os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
        
        self.endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        self.api_key = os.getenv("AZURE_OPENAI_API_KEY")
        self.api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-05-01-preview")
        
        if not self.api_key or not self.endpoint:
            logger.warning("Azure OpenAI environment variables are missing. Initialization may fail.")
            
        self.client = AzureOpenAI(
            api_key=self.api_key,
            api_version=self.api_version,
            azure_endpoint=self.endpoint
        )

    def _create_with_backoff(self, messages, max_transient_retries: int = 4):
        """
        Call the chat completion endpoint, retrying transient failures
        (429 rate limits, timeouts, 5xx) with exponential backoff + jitter so a
        momentary rate limit does not abort the whole pipeline run.
        """
        delay = 1.0
        for t in range(1, max_transient_retries + 1):
            try:
                return self.client.chat.completions.create(
                    model=self.deployment_name,
                    messages=messages,
                    response_format={"type": "json_object"},
                    temperature=0.0,
                )
            except TRANSIENT_LLM_ERRORS as e:
                if t >= max_transient_retries:
                    logger.error(f"Transient LLM error after {t} attempts; giving up: {type(e).__name__}: {e}")
                    raise
                sleep_s = delay + random.uniform(0, 0.5)
                logger.warning(
                    f"Transient LLM error ({type(e).__name__}); backing off {sleep_s:.1f}s "
                    f"(attempt {t}/{max_transient_retries})"
                )
                time.sleep(sleep_s)
                delay *= 2

    def generate_structured(
        self,
        prompt: str,
        system_prompt: str,
        response_model: Type[BaseModel],
        max_retries: int = 3
    ) -> BaseModel:
        
        attempt = 0
        current_prompt = prompt
        
        # Append schema instructions for JSON mode
        schema_json = json.dumps(response_model.model_json_schema())
        system_msg = f"{system_prompt}\n\nYou MUST return ONLY valid JSON matching the following schema:\n{schema_json}"
        
        while attempt < max_retries:
            attempt += 1
            start_time = time.time()
            
            try:
                logger.info(f"LLM Call Attempt {attempt}/{max_retries} to Azure model: {self.deployment_name}")
                
                response = self._create_with_backoff(
                    messages=[
                        {"role": "system", "content": system_msg},
                        {"role": "user", "content": current_prompt}
                    ]
                )
                
                latency = time.time() - start_time
                
                response_text = response.choices[0].message.content
                tokens = response.usage.total_tokens if response.usage else "unknown"
                    
                logger.info(f"LLM Response - Model: {self.deployment_name}, Latency: {latency:.2f}s, Tokens: {tokens}, Status: Success")
                
                if not response_text:
                     raise ValidationError.from_exception_data(
                        title="LLMParsingError",
                        line_errors=[{"type": "value_error", "loc": ("response",), "msg": "Response text is empty"}]
                    )

                # Parse the JSON string into the Pydantic model
                parsed_output = response_model.model_validate_json(response_text)

                # Defensive post-validation: coerce every List[str] field to actual list of strings.
                coerce_list_str_fields(parsed_output, response_model)

                logger.info(
                    f"LLM Field-Types - Model: {self.deployment_name}, "
                    f"Types: {summarize_field_types(parsed_output, response_model)}"
                )

                return parsed_output

            except ValidationError as e:
                latency = time.time() - start_time
                logger.warning(f"LLM Response - Latency: {latency:.2f}s, Status: Validation Failed - {e}")
                
                if attempt >= max_retries:
                    logger.error("Max retries reached. Failing.")
                    raise
                    
                # Append validation errors to the prompt for the next attempt
                error_msg = f"Your previous response failed schema validation. Please correct the following errors:\n{str(e)}\n\nOriginal request:\n{prompt}"
                current_prompt = error_msg
                
            except Exception as e:
                latency = time.time() - start_time
                logger.error(f"LLM Response - Latency: {latency:.2f}s, Status: Error - {e}")
                raise
