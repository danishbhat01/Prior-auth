from abc import ABC, abstractmethod
from typing import Dict, Any, Type, Optional
from pydantic import BaseModel

class BaseLLM(ABC):
    """
    Abstract interface for LLM inference providers.
    """
    
    @abstractmethod
    def generate_structured(
        self,
        prompt: str,
        system_prompt: str,
        response_model: Type[BaseModel],
        max_retries: int = 3
    ) -> BaseModel:
        """
        Generates a structured response strictly conforming to the response_model.
        
        Args:
            prompt: The user input prompt.
            system_prompt: The system instructions.
            response_model: The Pydantic model to enforce.
            max_retries: Number of retries if validation fails.
            
        Returns:
            An instance of the response_model.
        """
        pass
