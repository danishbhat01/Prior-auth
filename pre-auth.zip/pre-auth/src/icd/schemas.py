"""
Pydantic schemas for the ICD Coding Agent.

The agent's typed handoff contract to the next phase. `extra="forbid"` keeps
the contract strict so downstream consumers (confidence gate, form filler)
can rely on a stable shape.
"""
from typing import List, Literal, Optional

from pydantic import BaseModel, ConfigDict


class ICDMapping(BaseModel):
    """
    One diagnosis and its deterministic ICD-10 mapping outcome.

    For unmapped diagnoses, `icd10_code` and `rare_disease` are explicitly
    `None`; `status` distinguishes mapped from unmapped so downstream code
    can branch on a single field.
    """
    model_config = ConfigDict(extra="forbid")

    diagnosis: str
    icd10_code: Optional[str]
    rare_disease: Optional[bool]
    confidence: Optional[float] = None  # deterministic KG match score (0..1); None when unmapped
    status: Literal["mapped", "unmapped", "review_required"]


class ICDCodingOutput(BaseModel):
    """
    Aggregate output of the ICD Coding Agent: one ICDMapping per unique
    diagnosis in the input, in input order.
    """
    model_config = ConfigDict(extra="forbid")

    mappings: List[ICDMapping] = []
