"""
ICD Coding Agent.

Single responsibility: map diagnoses produced by the Extractor Agent to
ICD-10 codes using a semantic/fuzzy knowledge graph.
Unmapped diagnoses or low-confidence rare diseases are flagged with
`status="review_required"` or `"unmapped"`.
"""
import time
from typing import Dict

from pydantic import ValidationError

from src.extractor.schemas import ExtractorOutput
from src.utils.logging import get_logger
from .knowledge_graph import get_graph
from .schemas import ICDMapping, ICDCodingOutput

logger = get_logger(__name__)


class ICDCodingAgent:
    """
    Maps each unique diagnosis from an `ExtractorOutput` to an `ICDMapping` using the Knowledge Graph.
    """

    def __init__(self) -> None:
        logger.info("Initializing ICDCodingAgent (Knowledge Graph Mode)")

    def code(self, extractor_output: ExtractorOutput, specialty: str = "") -> ICDCodingOutput:
        start = time.perf_counter()
        raw_diagnoses: list[str] = list(extractor_output.diagnosis or [])
        input_count = len(raw_diagnoses)
        
        inferred = False
        if not raw_diagnoses and extractor_output.symptoms:
            # Infer diagnosis from symptoms to avoid failing downstream, heavily hedged.
            combined_symptoms = " ".join(extractor_output.symptoms)
            if combined_symptoms.strip():
                raw_diagnoses = [f"suspected {combined_symptoms}"]
                inferred = True
                input_count = 1

        unique_seen: Dict[str, str] = {}
        skipped_empty = 0
        for raw in raw_diagnoses:
            if not raw or not str(raw).strip():
                skipped_empty += 1
                continue
            stripped = str(raw).strip()
            unique_seen[stripped] = stripped

        graph = get_graph()
        mappings: list[ICDMapping] = []
        mapped_count = 0
        unmapped_count = 0
        review_required_count = 0

        seen_icd_codes = set()
        
        # Heuristic: convert clinical modifiers into a single string to act as body_region matching fallback
        body_region_hint = " ".join(extractor_output.clinical_modifiers or [])
        
        for original in unique_seen.values():
            # Combine symptoms and diagnosis for better matching context
            symptoms = extractor_output.symptoms or [] if not inferred else [] # Don't duplicate symptoms if already inferred
            icd_code, rare, confidence = None, None, None
            status = "unmapped"

            if inferred:
                # Flowchart: Look for explicit clinical evidence (Diseases only)
                candidates = graph.match(original, symptoms, is_symptom=False, top_k=1, specialty=specialty, body_region=body_region_hint)
                if candidates and candidates[0].score >= 0.35:
                    # YES -> Suggested diagnosis -> Review Required
                    top = candidates[0]
                    icd_code = top.code
                    rare = top.is_rare_disease
                    confidence = round(top.score, 4)
                    status = "review_required"
                    review_required_count += 1
                    logger.warning(f"Inferred diagnosis from symptoms with strong evidence ({top.score:.2f}) -> {icd_code}. Triggering Review.")
                else:
                    # NO -> Symptom ICD
                    candidates_sym = graph.match(original, symptoms, is_symptom=True, top_k=1, specialty=specialty, body_region=body_region_hint)
                    if candidates_sym:
                        top = candidates_sym[0]
                        icd_code = top.code
                        rare = top.is_rare_disease
                        confidence = round(top.score, 4)
                        # A rare disease always goes to human review, even inferred from symptoms.
                        if rare:
                            status = "review_required"
                            review_required_count += 1
                            logger.warning(f"Rare disease detected via symptom fallback -> {icd_code}. Routing to human review.")
                        else:
                            status = "mapped"
                            mapped_count += 1
                        logger.warning(f"Inferred diagnosis lacked strong evidence. Fell back to Symptom ICD -> {icd_code}.")
                    else:
                        unmapped_count += 1
            else:
                candidates = graph.match(original, symptoms, top_k=1, specialty=specialty, body_region=body_region_hint)
                if candidates:
                    top = candidates[0]
                    icd_code = top.code
                    rare = top.is_rare_disease
                    confidence = round(top.score, 4)

                    # Confidence gating rules.
                    # RULE: every rare disease is suspended for human review, regardless of
                    # coding confidence — rare-disease coding is high-risk and always warrants a human.
                    if rare:
                        status = "review_required"
                        review_required_count += 1
                        logger.warning(f"Rare disease detected (confidence {top.score:.2f}) -> {icd_code}. Routing to human review.")
                    elif top.score < 0.70:
                        status = "review_required"
                        review_required_count += 1
                        logger.warning(f"General disease mapped with low confidence ({top.score:.2f}) -> {icd_code}. Triggering Review.")
                    else:
                        status = "mapped"
                        mapped_count += 1
                else:
                    unmapped_count += 1
                
            # Deduplicate mappings: If we already mapped a disease to this exact ICD code, skip it
            # to avoid duplicated output. We allow multiple "unmapped" entries to pass through.
            if icd_code and icd_code in seen_icd_codes:
                logger.info(f"Skipping duplicate ICD code {icd_code} for diagnosis '{original}'.")
                # Need to decrement the counters since we are dropping it
                if status == "mapped": mapped_count -= 1
                if status == "review_required": review_required_count -= 1
                continue
                
            if icd_code:
                seen_icd_codes.add(icd_code)

            try:
                # If inferred, strip the artificial "suspected " prefix so the output schema is clean
                out_diagnosis = original[len("suspected "):] if inferred and original.startswith("suspected ") else original
                mapping = ICDMapping(
                    diagnosis=out_diagnosis,
                    icd10_code=icd_code,
                    rare_disease=rare,
                    confidence=confidence,
                    status=status,
                )
            except ValidationError as e:
                logger.error(f"Failed to construct ICDMapping for {original!r}: {e}")
                raise
            mappings.append(mapping)

        elapsed_ms = (time.perf_counter() - start) * 1000.0
        logger.info(
            f"ICD Coding complete: input={input_count} inferred={inferred} "
            f"mapped={mapped_count} unmapped={unmapped_count} review_required={review_required_count} "
            f"skipped_empty={skipped_empty} elapsed_ms={elapsed_ms:.2f}"
        )

        return ICDCodingOutput(mappings=mappings)
