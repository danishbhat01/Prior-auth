"""Mini ICD-10 knowledge graph (NetworkX) + keyword/fuzzy matcher used by the ICD Coder agent.

Deliberately NOT an LLM call: coding confidence must be deterministic and explainable so the
confidence gate (rare-disease threshold 0.90) behaves consistently across runs.
"""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path

import networkx as nx
import pandas as pd

REPO_ROOT = Path(__file__).resolve().parents[2]
_DEFAULT_DATA_PATH = REPO_ROOT / "Dataset" / "icd" / "icd_master_dataset.xlsx"

_STOPWORDS = {
    "a", "an", "the", "of", "with", "for", "and", "or", "in", "on", "to", "is", "are",
    "patient", "has", "shows", "confirmed", "confirms", "documented", "advanced",
}

# Hedging language dampens coding confidence: a coder should not assign full confidence to a
# diagnosis that the note itself frames as unconfirmed. This is what lets a rare-disease case
# read as clinically clear yet still land under the 0.90 confidence gate.
_HEDGE_PATTERNS = [
    "suspected", "suspicious for", "possible", "probable", "pending confirmation",
    "pending confirmatory", "rule out", "r/o", "concern for", "presumed", "query",
    "awaiting genetic", "awaiting confirmatory",
]
_HEDGE_DAMPENING = 0.85

# A single word can be long enough (>=8 chars) to pass the "distinctive phrase" length check
# below while still being medically generic — a descriptor ("degenerative", "bilateral") or a
# bare organ name ("pancreas", "gallbladder") rather than a diagnosis-specific term. Letting
# those trigger the verbatim-match confidence shortcut is how a knee note ends up confidently
# (and wrongly) coded as hip disease, or a benign pancreas mention as pancreatic cancer — so
# they're excluded from the shortcut regardless of length/uniqueness and fall back to the
# graduated token-recall + fuzzy score instead.
_GENERIC_SHORTCUT_BLOCKLIST = {
    "bilateral", "unilateral", "degenerative", "chronic", "acute", "advanced", "unspecified",
    "progressive", "recurrent", "severe", "mild", "moderate", "persistent", "intermittent",
    "pancreas", "gallbladder", "colon", "liver", "kidney", "lung", "brain", "heart", "spleen",
    "thyroid", "prostate", "stomach", "bladder", "breast", "ovary",
}

# A keyword like "left hip" or "right knee" is a *side + body part* locator, not a diagnosis —
# many different conditions occur in the left hip. It's excluded from the shortcut for the same
# reason as the blocklist above, but structurally rather than by name: a keyword's diagnostic
# specificity has to come from the disease/finding word(s), not merely from pairing a laterality
# word with an anatomy word. (Laterality itself is already handled separately via the dedicated
# `laterality` field/penalty below — it doesn't need to double as a confidence signal here too.)
# This is also what closes the loophole where a short 2-word phrase like "left hip" can pass the
# blocklist AND the doc-count uniqueness check yet still score high by fuzzy coincidence against
# an unrelated note that merely shares the word "left".
_LATERALITY_WORDS = {"left", "right", "bilateral"}


def _is_bare_laterality_locator(keyword: str) -> bool:
    words = keyword.lower().split()
    return len(words) == 2 and words[0] in _LATERALITY_WORDS


def _tokenize(text: str) -> set[str]:
    words = re.findall(r"[a-z0-9']+", text.lower())
    return {w for w in words if w not in _STOPWORDS and len(w) > 1}


def _has_hedge_language(text: str) -> bool:
    lowered = text.lower()
    return any(pattern in lowered for pattern in _HEDGE_PATTERNS)


def _word_boundary_contains(haystack: str, needle: str) -> bool:
    """Substring containment, but anchored to word boundaries so a short keyword/abbreviation
    (e.g. "ms", "als", "cf") can't false-positive-match inside an unrelated longer word
    (e.g. "ms" inside "symptoms", "als" inside "also")."""
    return re.search(r"\b" + re.escape(needle) + r"\b", haystack) is not None


_MIN_MEANINGFUL_MATCH_CHARS = 6


def _containment_score(query_lower: str, target_lower: str) -> float:
    """1.0 if `target_lower` (a keyword phrase or description) appears verbatim in the query
    (or vice versa) at a word boundary; otherwise the longest-common-substring length relative
    to the target, which behaves like a "partial ratio" fuzzy match without a rapidfuzz dependency.

    A short target (e.g. an 8-character word like "dementia") can share a purely coincidental
    substring with unrelated text — "replacement" contains "ement", which also sits inside
    "dementia" — and score deceptively high purely because the ratio's denominator is small, not
    because the overlap means anything. Matches shorter than a meaningful floor don't count at
    all, so a handful of coincidentally shared letters can no longer outscore a real match.
    """
    if _word_boundary_contains(query_lower, target_lower) or _word_boundary_contains(target_lower, query_lower):
        return 1.0
    matcher = SequenceMatcher(None, query_lower, target_lower)
    match = matcher.find_longest_match(0, len(query_lower), 0, len(target_lower))
    if match.size < _MIN_MEANINGFUL_MATCH_CHARS:
        return 0.0
    return match.size / max(1, len(target_lower))


@dataclass
class Candidate:
    code: str
    description: str
    score: float
    laterality: str
    laterality_match: bool
    is_rare_disease: bool
    is_symptom: bool
    category: str
    specialty: str
    body_region: str


class ICD10KnowledgeGraph:
    def __init__(self, data_path: Path | None = None) -> None:
        self.data_path = data_path or _DEFAULT_DATA_PATH
        self.graph = nx.DiGraph()
        self._load()

    def _load(self) -> None:
        df = pd.read_excel(self.data_path)
        records = df.to_dict(orient="records")

        all_keywords = []
        for rec in records:
            code = str(rec["icd10_code"]).strip()
            diagnosis = str(rec["diagnosis"]).strip()
            rare_disease = str(rec.get("rare_disease", "No")).strip().lower() == "yes"
            specialty = str(rec.get("specialty", "")).strip()
            body_region = str(rec.get("body_region", "")).strip()
            
            category = code[:3] if len(code) >= 3 else code
            is_symptom = code.startswith("R") or "pain" in diagnosis.lower()
            
            # Synthesize keywords by tokenizing the diagnosis
            tokens = _tokenize(diagnosis)
            keywords = [diagnosis] + list(tokens)
            
            # Infer laterality
            laterality = "not_applicable"
            diag_lower = diagnosis.lower()
            if "left" in diag_lower:
                laterality = "left"
            elif "right" in diag_lower:
                laterality = "right"
            elif "bilateral" in diag_lower:
                laterality = "bilateral"

            node_data = {
                "code": code,
                "description": diagnosis,
                "category": category,
                "rare_disease": rare_disease,
                "is_symptom": is_symptom,
                "keywords": keywords,
                "laterality": laterality,
                "specialty": specialty,
                "body_region": body_region
            }

            if not self.graph.has_node(category):
                self.graph.add_node(category, kind="category")
            self.graph.add_node(code, kind="code", **node_data)
            self.graph.add_edge(category, code)

            all_keywords.extend([kw.lower() for kw in keywords])

        # A keyword phrase shared across several codes (e.g. "malignant neoplasm", "lysosomal
        # storage") is not distinctive evidence for any ONE of them — track corpus-wide
        # frequency so match() can tell a code-specific phrase from a generic category term.
        self._keyword_doc_count = Counter(all_keywords)

    def codes(self, is_symptom: bool | None = None) -> list[dict]:
        return [
            data for _, data in self.graph.nodes(data=True) 
            if data.get("kind") == "code" and (is_symptom is None or data.get("is_symptom") == is_symptom)
        ]

    def match(
        self,
        diagnosis_text: str,
        symptoms: list[str] | None = None,
        laterality: str = "not_applicable",
        is_symptom: bool | None = None,
        specialty: str = "",
        body_region: str = "",
        top_k: int = 5,
    ) -> list[Candidate]:
        query_text = diagnosis_text + " " + " ".join(symptoms or [])
        query_tokens = _tokenize(query_text)
        query_lower = diagnosis_text.lower()
        hedged = _has_hedge_language(diagnosis_text)
        
        specialty_lower = specialty.lower()
        body_region_lower = body_region.lower()

        scored: list[Candidate] = []
        for node in self.codes(is_symptom=is_symptom):
            node_tokens = _tokenize(" ".join(node["keywords"]) + " " + node["description"])
            token_recall = len(query_tokens & node_tokens) / max(1, len(query_tokens))

            # Only a phrase that is BOTH multi-word and unique to this one code (or the full
            # description, always code-specific by construction) can earn the confident-match
            # shortcut below. A single generic word (e.g. "tremor") or a phrase shared across
            # several related codes (e.g. "lysosomal storage", "malignant neoplasm") must not
            # out-rank a real code-specific match elsewhere.
            distinctive_targets = [
                kw for kw in node["keywords"]
                if (len(kw.split()) >= 2 or len(kw) >= 8)
                and kw.lower() not in _GENERIC_SHORTCUT_BLOCKLIST
                and not _is_bare_laterality_locator(kw)
                and self._keyword_doc_count[kw.lower()] == 1
            ] + [node["description"]]
            best_fuzzy = 0.0
            best_match_len = 0
            for target in distinctive_targets:
                s = _containment_score(query_lower, target.lower())
                if s > best_fuzzy:
                    best_fuzzy = s
                    best_match_len = len(target)

            if best_fuzzy >= 0.999:
                # A defining keyword/description phrase appears verbatim in the query — treat
                # this as a confident match regardless of how much other narrative surrounds it
                # (token_recall alone would otherwise dilute long real-world notes unfairly).
                # Longer/more specific matched phrases nudge the score higher, so a
                # disease-specific phrase outranks a short phrase shared across several
                # related conditions (e.g. "lysosomal storage" appears for several disorders).
                score = 0.90 + 0.07 * min(1.0, best_match_len / 35)
            else:
                score = 0.15 * token_recall + 0.85 * best_fuzzy
            if hedged:
                score *= _HEDGE_DAMPENING

            node_laterality = node.get("laterality", "not_applicable")
            laterality_match = True
            if node_laterality in ("left", "right", "bilateral") and laterality in ("left", "right", "bilateral"):
                if node_laterality != laterality:
                    laterality_match = False
                    score *= 0.5
                    
            # Boost score based on specialty and body_region if provided
            node_specialty = node.get("specialty", "").lower()
            node_body_region = node.get("body_region", "").lower()
            
            if specialty_lower and node_specialty and specialty_lower == node_specialty:
                score *= 1.1  # 10% boost for matching specialty
            if body_region_lower and node_body_region and body_region_lower == node_body_region:
                score *= 1.15 # 15% boost for matching body region

            score = round(min(1.0, score), 4)
            scored.append(
                Candidate(
                    code=node["code"],
                    description=node["description"],
                    score=score,
                    laterality=node_laterality,
                    laterality_match=laterality_match,
                    is_rare_disease=bool(node.get("rare_disease", False)),
                    is_symptom=bool(node.get("is_symptom", False)),
                    category=node["category"],
                    specialty=node.get("specialty", ""),
                    body_region=node.get("body_region", "")
                )
            )

        scored.sort(key=lambda c: c.score, reverse=True)
        return scored[:top_k]


_graph_singleton: ICD10KnowledgeGraph | None = None


def get_graph() -> ICD10KnowledgeGraph:
    global _graph_singleton
    if _graph_singleton is None:
        _graph_singleton = ICD10KnowledgeGraph()
    return _graph_singleton
