import json
from src.llm.interfaces import BaseLLM
from src.utils.logging import get_logger
from src.form.schemas import PriorAuthForm
from .schemas import CritiqueReport

logger = get_logger(__name__)

CRITIQUE_SYSTEM_PROMPT = """
You are a QA Critique Agent for a medical prior authorization pipeline. You are a
FORM-INTEGRITY gate, NOT the medical-necessity reviewer. You do NOT decide approval,
and you do NOT re-check whether insurer policy criteria are met — the Policy Agent and
the Insurer Review Agent own those decisions. Your ONLY job is to make sure the assembled
form is structurally sound and internally consistent before it reaches the payer.

CHECK ONLY THESE:
1. Mandatory identifiers are present: patient_id, policy_number, specialty, at least one
   diagnosis, and at least one ICD mapping.
2. The ICD code(s) are consistent with the stated diagnosis (no clear contradiction).
3. No internal contradiction between fields (e.g. laterality: diagnosis says "left knee"
   but the requested procedure says "right knee").

DO NOT FAIL THE FORM FOR:
- Medical necessity, sufficiency of clinical evidence, or whether policy criteria are met
  (that is the Policy Agent's and Insurer Review Agent's responsibility, not yours).
- A generally-worded requested procedure (e.g. "definitive management") — that is acceptable here.
- Missing OPTIONAL clinical detail (imaging, labs, serology) that the note simply did not include.

SEVERITY CALIBRATION:
- result = PASS (severity "non-critical") when the mandatory identifiers are present and there
  is no internal contradiction. This should be the common case. When in doubt, PASS.
- result = FAIL, severity = "critical" ONLY for a true structural break a human must fix:
  a missing mandatory identifier, an empty ICD mapping when a diagnosis exists, or a direct
  diagnosis/ICD or laterality contradiction.
- result = FAIL, severity = "non-critical" for a minor issue a single retry could resolve.
"""

class CritiqueAgent:
    """
    LLM-powered Agent that reviews the populated PriorAuthForm for completeness and logical consistency.
    """
    
    def __init__(self, llm_client: BaseLLM):
        logger.info("Initializing CritiqueAgent (LLM Mode)")
        self.llm_client = llm_client
        
    def critique(self, form: PriorAuthForm) -> CritiqueReport:
        logger.info(f"Critiquing PriorAuthForm for patient_id: {form.patient_id}")
        
        user_prompt = f"""
## Prior Authorization Form:
{json.dumps(form.model_dump(), indent=2)}

Please critique this form against the verification checklist and return the CritiqueReport schema.
"""
        try:
            output = self.llm_client.generate_structured(
                prompt=user_prompt,
                system_prompt=CRITIQUE_SYSTEM_PROMPT,
                response_model=CritiqueReport,
                max_retries=3
            )
            logger.info(f"Critique complete: RESULT={output.result} SEVERITY={output.severity}")
            return output # type: ignore
        except Exception as e:
            logger.error(f"Critique failed: {e}")
            raise
