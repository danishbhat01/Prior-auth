from typing import List, Literal
from pydantic import BaseModel, Field

class CritiqueReport(BaseModel):
    """
    LLM output representing a rigorous critique of the fully populated PriorAuthForm.
    """
    result: Literal["PASS", "FAIL"] = Field(
        description="PASS if the form is complete and logically sound. FAIL if missing information, contradictions, or invalid codes are found."
    )
    severity: Literal["critical", "non-critical"] = Field(
        default="non-critical",
        description="If result is FAIL, severity is critical if the issue cannot be resolved without manual intervention. Severity is non-critical if it can be resolved with a retry."
    )
    issues: List[str] = Field(
        default_factory=list, 
        description="List of specific issues found in the form (e.g. missing fields, diagnosis/ICD mismatch, policy evidence weak)."
    )
    recommendations: List[str] = Field(
        default_factory=list, 
        description="Actionable recommendations to fix the identified issues."
    )
